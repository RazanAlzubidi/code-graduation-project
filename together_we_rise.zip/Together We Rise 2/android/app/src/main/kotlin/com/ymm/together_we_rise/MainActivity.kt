package com.ymm.together_we_rise

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
