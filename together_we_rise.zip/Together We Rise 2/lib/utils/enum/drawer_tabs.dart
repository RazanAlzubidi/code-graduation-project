import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/auth_view_model.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/chat/chat_users.dart';
import 'package:together_we_rise/view/drawer_pages/report_problem.dart';
import 'package:together_we_rise/view/drawer_pages/reset_password.dart';
import 'package:together_we_rise/view/profile_view.dart';
import 'package:together_we_rise/view/tabbar/main_tab_bar.dart';

import 'language_enum.dart';

enum DrawerTabs {
  homePage,
  profile,
  changeLanguage,
  resetPassword,
  reportProblem,
  chat,
  logOut,
}

extension DrawerTabsExtension on DrawerTabs {
  String get title {
    switch (this) {
      case DrawerTabs.homePage:
        return "Home page".tr;
      case DrawerTabs.profile:
        return "Profile".tr;
      case DrawerTabs.changeLanguage:
        return "Change language".tr;
      case DrawerTabs.resetPassword:
        return "Reset password".tr;
      case DrawerTabs.reportProblem:
        return "Report a problem".tr;
      case DrawerTabs.chat:
        return "Chat".tr;
      case DrawerTabs.logOut:
        return "logout".tr;
    }
  }

  Function get action {
    switch (this) {
      case DrawerTabs.homePage:
        return () => Get.offAll(() => const UserTabBar());
      case DrawerTabs.profile:
        return () => Get.to(() => const ProfileView());
      case DrawerTabs.changeLanguage:
        return () {
          if (Get.locale == LanguageEnum.arabic.locale) {
            Get.updateLocale(LanguageEnum.english.locale);
            UserProfile.shared.setLanguage(lang: LanguageEnum.english);
            UserProfile.shared.language = LanguageEnum.english;
          } else {
            Get.updateLocale(LanguageEnum.arabic.locale);
            UserProfile.shared.setLanguage(lang: LanguageEnum.arabic);
            UserProfile.shared.language = LanguageEnum.arabic;
          }
        };
      case DrawerTabs.chat:
        return () => Get.to(() => ChatUsers());
      case DrawerTabs.resetPassword:
        return () => Get.to(() => const ResetPasswordView());
      case DrawerTabs.reportProblem:
        return () => Get.to(() => ReportProblemView());
      case DrawerTabs.logOut:
        return () => Get.put(AuthViewModel()).signOut();
    }
  }
}
