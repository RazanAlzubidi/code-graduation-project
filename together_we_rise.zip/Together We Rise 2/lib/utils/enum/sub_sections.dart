import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';

enum SubSections {
  book,
  electronic,
  clothes,
  tools,
  other,
}

extension SubSectionsExtension on SubSections {
  String get title {
    switch (this) {
      case SubSections.book:
        return "Book".tr;
      case SubSections.electronic:
        return "Electronic".tr;
      case SubSections.clothes:
        return "Clothes".tr;
      case SubSections.tools:
        return "Tools".tr;
      case SubSections.other:
        return "Other".tr;
    }
  }

  String get image {
    switch (this) {
      case SubSections.book:
        return Assets.shared.icBook;
      case SubSections.electronic:
        return Assets.shared.icElectronic;
      case SubSections.clothes:
        return Assets.shared.icClothes;
      case SubSections.tools:
        return Assets.shared.icTools;
      case SubSections.other:
        return Assets.shared.icOthers;
    }
  }
}
