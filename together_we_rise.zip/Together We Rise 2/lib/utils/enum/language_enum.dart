import 'package:flutter/cupertino.dart';

enum LanguageEnum {
  english,
  arabic,
}

extension LanguageEnumExtension on LanguageEnum {
  Locale get locale {
    switch (this) {
      case LanguageEnum.english:
        return const Locale('en', 'US');
      case LanguageEnum.arabic:
        return const Locale('ar', 'SA');
    }
  }
}
