import 'package:get/get.dart';

enum TypeOfSale {
  sale,
  buying,
}

extension TypeOfSaleExtenstion on TypeOfSale {
  String get title {
    switch (this) {
      case TypeOfSale.sale:
        return "brrowing".tr;
      case TypeOfSale.buying:
        return "Buying".tr;
    }
  }
}
