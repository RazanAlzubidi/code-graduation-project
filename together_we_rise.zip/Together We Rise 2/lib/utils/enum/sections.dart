import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';

enum Sections {
  mathematics,
  computerScience,
  english,
  chemistry,
  islamicCulture,
  interiorDesign,
}

extension SectionsExtension on Sections {
  String get title {
    switch (this) {
      case Sections.mathematics:
        return "Mathematics".tr;
      case Sections.computerScience:
        return "Computer Science".tr;
      case Sections.english:
        return "English".tr;
      case Sections.chemistry:
        return "Chemistry".tr;
      case Sections.islamicCulture:
        return "Islamic Culture".tr;
      case Sections.interiorDesign:
        return "Interior Design".tr;
    }
  }

  String get image {
    switch (this) {
      case Sections.mathematics:
        return Assets.shared.icMathematics;
      case Sections.computerScience:
        return Assets.shared.icComputerScience;
      case Sections.english:
        return Assets.shared.icEnglish;
      case Sections.chemistry:
        return Assets.shared.icChemistry;
      case Sections.islamicCulture:
        return Assets.shared.icIslamicCulture;
      case Sections.interiorDesign:
        return Assets.shared.icInteriorDesign;
    }
  }
}
