enum FileTypeEnum { image, video, file }

extension FileType on FileTypeEnum {
  String get contentType {
    switch (this) {
      case FileTypeEnum.image:
        return "image/png";
      case FileTypeEnum.video:
        return "video/mp4";
      case FileTypeEnum.file:
        return "application/pdf";
    }
  }
}
