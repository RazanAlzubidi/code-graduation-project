enum ProfilePageType {
  mySales,
  myPurchases,
}
