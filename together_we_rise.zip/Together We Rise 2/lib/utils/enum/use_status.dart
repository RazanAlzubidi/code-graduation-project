import 'package:get/get.dart';

enum UseStatus {
  newStatus,
  usedInExcellentCondition,
  usedInVeryGoodCondition,
  usedInGoodCondition,
}

extension UseStatusExtension on UseStatus {
  String get title {
    switch (this) {
      case UseStatus.newStatus:
        return "New".tr;
      case UseStatus.usedInExcellentCondition:
        return "Used in excellent condition".tr;
      case UseStatus.usedInVeryGoodCondition:
        return "Used in very good condition".tr;
      case UseStatus.usedInGoodCondition:
        return "Used in good condition".tr;
    }
  }
}
