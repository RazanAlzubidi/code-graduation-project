import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';

enum PaymentType {
  cardPay,
  applePay,
  stcPay,
}

extension PaymentTypeExtension on PaymentType {
  String get title {
    switch (this) {
      case PaymentType.cardPay:
        return "pay with card".tr;
      case PaymentType.applePay:
        return "Apple pay".tr;
      case PaymentType.stcPay:
        return "Stc pay".tr;
    }
  }

  String get icon {
    switch (this) {
      case PaymentType.cardPay:
        return Assets.shared.icCardPay;
      case PaymentType.applePay:
        return Assets.shared.icApplePay;
      case PaymentType.stcPay:
        return Assets.shared.icStcPay;
    }
  }
}
