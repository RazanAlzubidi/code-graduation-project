import 'package:flutter/material.dart';

const authBorder = UnderlineInputBorder(
  borderSide: BorderSide(
    color: Colors.black,
    width: 1.0,
  ),
);
