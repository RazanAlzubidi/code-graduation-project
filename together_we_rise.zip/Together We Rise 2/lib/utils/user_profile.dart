import 'dart:developer';

import 'package:get_storage/get_storage.dart';
import 'package:together_we_rise/model/order_model.dart';
import 'package:together_we_rise/model/user_model.dart';

import 'enum/language_enum.dart';

class UserProfile {
  static final shared = UserProfile();

  final _box = GetStorage();

  UserModel? currentUser;

  OrderModel? tempOrder;

  LanguageEnum? language;

  Future<UserModel?> getUser() async {
    try {
      return _box.read('current-user') == ""
          ? null
          : userModelFromJson(_box.read('current-user'));
    } catch (e) {
      return null;
    }
  }

  setUser({required UserModel? user}) async {
    try {
      if (user == null) {
        _box.remove('current-user');
        currentUser = null;
        return;
      }

      await _box.write('current-user', userModelToJson(user));
    } catch (e) {
      log(e.toString());
    }
  }

  Future<LanguageEnum?> getLanguage() async {
    try {
      LanguageEnum? lang = _box.read('language') == null
          ? null
          : LanguageEnum.values[_box.read('language')];

      language = lang;

      return lang;
    } catch (e) {
      return null;
    }
  }

  setLanguage({required LanguageEnum lang}) async {
    try {
      await _box.write('language', lang.index);
    } catch (e) {
      log(e.toString());
    }
  }
}
