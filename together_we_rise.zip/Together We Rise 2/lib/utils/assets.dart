import 'package:flutter/material.dart';
import 'package:together_we_rise/utils/extenstion.dart';

const String _imagesPath = "assets/images/";

const String _iconsPath = "${_imagesPath}icons/";

class Assets {
  static final shared = Assets();

  // TODO: - Colors

  final Color primaryColor = "#6A4814".toHexaColor();

  final Color secondaryColor = const Color.fromRGBO(109, 109, 109, 1);

  // TODO: - Fonts

  final String primaryFont = 'NeoSansArabic';

  // TODO: - Icons

  final String icHeart = "${_iconsPath}ic-heart.png";

  final String icEmail = "${_iconsPath}ic-email.png";

  final String icMoney = "${_iconsPath}ic-money.png";

  final String icSuccess = "${_iconsPath}ic-success.png";

  final String icCardPay = "${_iconsPath}ic-card-pay.png";

  final String icApplePay = "${_iconsPath}ic-apple-pay.png";

  final String icStcPay = "${_iconsPath}ic-stc-pay.png";

  final String icAddPicture = "${_iconsPath}ic-add-picture.png";

  final String icAdd = "${_iconsPath}ic-add.svg";

  final String icUser = "${_iconsPath}ic-user.svg";

  final String icHome = "${_iconsPath}ic-home.svg";

  final String icClothes = "${_iconsPath}ic-clothes.png";

  final String icElectronic = "${_iconsPath}ic-electronic.jpg";

  final String icBook = "${_iconsPath}ic-book.png";

  final String icTools = "${_iconsPath}ic-tools.jpg";

  final String icOthers = "${_iconsPath}ic-other.png";

  final String icChemistry = "${_iconsPath}ic-chemistry.jpg";

  final String icComputerScience = "${_iconsPath}ic-computer-science.png";

  final String icEnglish = "${_iconsPath}ic-english.jpg";

  final String icInteriorDesign = "${_iconsPath}ic-interior-design.png";

  final String icIslamicCulture = "${_iconsPath}ic-islamic-culture.jpg";

  final String icMathematics = "${_iconsPath}ic-mathematics.jpg";
}
