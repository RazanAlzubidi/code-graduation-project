import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class ImagePickerHelper {
  static final ImagePickerHelper shared = ImagePickerHelper();

  getImage({required Function(String image) callback}) {
    showModalBottomSheet(
      context: Get.context!,
      builder: (BuildContext bc) {
        return Wrap(
          children: <Widget>[
            ListTile(
              leading: Icon(
                Icons.camera_alt,
                color: Theme.of(Get.context!).primaryColor,
              ),
              title: Text(
                "Camera".tr,
                style: TextStyle(color: Theme.of(Get.context!).primaryColor),
              ),
              onTap: () async {
                String image =
                    await _selectImage(imageSource: ImageSource.camera);
                callback(image);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.image,
                color: Theme.of(Get.context!).primaryColor,
              ),
              title: Text(
                "Gallery".tr,
                style: TextStyle(color: Theme.of(Get.context!).primaryColor),
              ),
              onTap: () async {
                String image =
                    await _selectImage(imageSource: ImageSource.gallery);
                callback(image);
              },
            ),
          ],
        );
      },
    );
  }

  _selectImage({required ImageSource imageSource}) async {
    XFile? image = await ImagePicker().pickImage(source: imageSource);
    Get.back();
    return image?.path;
  }
}
