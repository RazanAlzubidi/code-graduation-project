import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/loader.dart';

extension StringExtensions on String {
  bool isValidEmail() => RegExp(
          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
      .hasMatch(this);

  bool isValidPassword() => length >= 6 && length <= 15;

  Color toHexaColor() {
    final buffer = StringBuffer();
    if (length == 6 || length == 7) buffer.write('ff');
    buffer.write(replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  String getId() {
    if (length < 3) {
      return "";
    }

    String id = "";

    for (var i = 0; i < 4; i++) {
      id += this[i].codeUnitAt(0).toString();
    }

    return id;
  }
}

extension DateTimeExtensions on DateTime {
  String convertToDateStringOnly() => "$year - $month - $day";
}

extension CustomExtenstionGetInterface on GetInterface {
  void customSnackbar({
    required String title,
    required String message,
    bool isError = false,
  }) {
    Get.snackbar(
      title,
      message,
      backgroundColor: isError ? Colors.red : Colors.green,
      colorText: Colors.white,
    );
  }

  void customLoader({bool isShowLoader = true}) {
    Get.find<LoaderViewModel>().showLoader(isShowLoader: isShowLoader);
  }
}
