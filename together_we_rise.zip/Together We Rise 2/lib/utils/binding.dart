import 'package:get/get_instance/src/bindings_interface.dart';

class Binding extends Bindings {
  @override
  void dependencies() {
    // Get.lazyPut(() => AuthViewModel());
  }
}
