import 'dart:convert';

import 'package:together_we_rise/utils/enum/user_type.dart';

UserModel userModelFromJson(String str) => UserModel.fromJson(json.decode(str));

String userModelToJson(UserModel data) => json.encode(data.toJson());

class UserModel {
  UserModel({
    required this.uid,
    required this.email,
    required this.name,
    required this.userType,
  });

  String? uid;
  String? email;
  String? name;
  UserType? userType;

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        uid: json["uid"],
        email: json["email"],
        name: json["name"],
        userType: json["user-type"] == null
            ? null
            : UserType.values[json["user-type"]],
      );

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "email": email,
        "name": name,
        "user-type": userType?.index,
      };
}
