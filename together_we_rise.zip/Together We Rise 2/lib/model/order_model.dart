import 'dart:convert';

OrderModel orderModelFromJson(String str) =>
    OrderModel.fromJson(json.decode(str));

String orderModelToJson(OrderModel data) => json.encode(data.toJson());

class OrderModel {
  OrderModel({
    required this.uid,
    required this.uidProduct,
    required this.uidSeller,
    required this.uidCustomer,
    required this.isBorrowing,
    required this.dateReceipt,
    required this.dateReturn,
    required this.createdDate,
  });

  String? uid;
  String? uidProduct;
  String? uidSeller;
  String? uidCustomer;
  bool? isBorrowing;
  String? dateReceipt;
  String? dateReturn;
  String? createdDate;

  factory OrderModel.fromJson(Map<String, dynamic> json) => OrderModel(
        uid: json["uid"],
        uidProduct: json["uid-product"],
        uidSeller: json["uid-seller"],
        uidCustomer: json["uid-customer"],
        isBorrowing: json["is-borrowing"],
        dateReceipt: json["date-receipt"],
        dateReturn: json["date-return"],
        createdDate: json["created-date"],
      );

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "uid-product": uidProduct,
        "uid-seller": uidSeller,
        "uid-customer": uidCustomer,
        "is-borrowing": isBorrowing,
        "date-receipt": dateReceipt,
        "date-return": dateReturn,
        "created-date": createdDate,
      };
}
