import 'dart:convert';

import 'package:together_we_rise/utils/enum/sections.dart';
import 'package:together_we_rise/utils/enum/sub_sections.dart';
import 'package:together_we_rise/utils/enum/type_of_sale.dart';
import 'package:together_we_rise/utils/enum/use_status.dart';

ProductModel productModelFromJson(String str) =>
    ProductModel.fromJson(json.decode(str));

String productModelToJson(ProductModel data) => json.encode(data.toJson());

class ProductModel {
  ProductModel({
    required this.uid,
    required this.name,
    required this.image,
    required this.price,
    required this.section,
    required this.subSection,
    required this.useStatus,
    required this.typeOfSale,
    required this.details,
    required this.contactInfo,
    required this.createdBy,
    required this.createdDate,
    required this.specialty,
  });

  String? uid;
  String? image;
  String? name;
  String? price;
  Sections? section;
  SubSections? subSection;
  UseStatus? useStatus;
  TypeOfSale? typeOfSale;
  String? details;
  String? contactInfo;
  String? createdBy;
  String? createdDate;
  String? specialty;

  factory ProductModel.fromJson(Map<String, dynamic> json) => ProductModel(
      uid: json["uid"],
      image: json["image"],
      name: json["name"],
      price: json["price"],
      section: Sections.values[json["section"]],
      subSection: SubSections.values[json["sub-section"]],
      useStatus: UseStatus.values[json["use-status"]],
      typeOfSale: TypeOfSale.values[json["type-of-sale"]],
      details: json["details"],
      contactInfo: json["contact-info"],
      createdBy: json["created-by"],
      createdDate: json["created-date"],
      specialty: json["specialty"]);

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "image": image,
        "name": name,
        "price": price,
        "section": section?.index,
        "sub-section": subSection?.index,
        "use-status": useStatus?.index,
        "type-of-sale": typeOfSale?.index,
        "details": details,
        "contact-info": contactInfo,
        "created-by": createdBy,
        "created-date": createdDate,
        "specialty": specialty,
      };
}
