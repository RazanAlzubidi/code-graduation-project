import 'dart:convert';

ChatModel chatModelFromJson(String str) => ChatModel.fromJson(json.decode(str));

String chatModelToJson(ChatModel data) => json.encode(data.toJson());

class ChatModel {
  ChatModel({
    required this.uidSender,
    required this.uidReceiver,
    required this.message,
    required this.date,
    required this.uid,
  });

  String? uidSender;
  String? uidReceiver;
  String? message;
  String? date;
  String? uid;

  factory ChatModel.fromJson(Map<String, dynamic> json) => ChatModel(
        uidSender: json["uid-sender"],
        uidReceiver: json["uid-receiver"],
        message: json["message"],
        date: json["date"],
        uid: json["uid"],
      );

  Map<String, dynamic> toJson() => {
        "uid-sender": uidSender,
        "uid-receiver": uidReceiver,
        "message": message,
        "date": date,
        "uid": uid,
      };
}
