import 'dart:convert';

ProblemModel problemModelFromJson(String str) =>
    ProblemModel.fromJson(json.decode(str));

String problemModelToJson(ProblemModel data) => json.encode(data.toJson());

class ProblemModel {
  ProblemModel({
    required this.title,
    required this.details,
    required this.dateCreated,
    required this.createdBy,
    required this.uid,
  });

  String? title;
  String? details;
  String? dateCreated;
  String? createdBy;
  String? uid;

  factory ProblemModel.fromJson(Map<String, dynamic> json) => ProblemModel(
        title: json["title"],
        details: json["details"],
        dateCreated: json["date-created"],
        createdBy: json["created-by"],
        uid: json["uid"],
      );

  Map<String, dynamic> toJson() => {
        "title": title,
        "details": details,
        "date-created": dateCreated,
        "created-by": createdBy,
        "uid": uid,
      };
}
