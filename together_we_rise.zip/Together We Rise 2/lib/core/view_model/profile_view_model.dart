import 'package:get/get.dart';
import 'package:together_we_rise/utils/enum/profile_page_type.dart';

class ProfileViewModel extends GetxController {
  ProfilePageType profileType = ProfilePageType.mySales;
}
