import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firestore_chat.dart';
import 'package:together_we_rise/core/service/firestore_user.dart';
import 'package:together_we_rise/model/chat_model.dart';
import 'package:together_we_rise/model/user_model.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/widgets/custom_alert_dialog.dart';

class UserViewModel extends GetxController {
  List<UserModel> allUsers = [];

  List<UserModel> users = [];

  void getUsers() async {
    allUsers = await FirestoreUser.shared.getAllUsers();

    for (var user in allUsers) {
      if (user.uid != UserProfile.shared.currentUser?.uid) {
        users.add(user);
      }
    }

    update();
  }

  void getUsersChat() async {
    users.clear();

    List<String> uidUsers = [];

    List<ChatModel> messages =
        await FirestoreChat.shared.getAllMessages().first;

    String myId = UserProfile.shared.currentUser?.uid ?? "";

    for (var message in messages) {
      if (message.uidSender == myId) {
        if (!uidUsers.contains(message.uidSender)) {
          uidUsers.add(message.uidSender ?? "");
        }
      } else if (message.uidReceiver == myId) {
        if (!uidUsers.contains(message.uidReceiver)) {
          uidUsers.add(message.uidReceiver ?? "");
        }
      }
    }

    for (var uid in uidUsers) {
      UserModel? user = await FirestoreUser.shared.getUserByUid(uid: uid);

      if (user != null) {
        users.add(user);
      }
    }

    update();
  }

  void search({required String keyword}) {
    users.clear();

    for (var user in allUsers) {
      if ((user.name?.toLowerCase() ?? "").contains(keyword.toLowerCase()) &&
          user.uid != UserProfile.shared.currentUser?.uid) {
        users.add(user);
      }
    }

    update();
  }

  void deleteUser({required String uid}) {
    customAlertDialog(
      title: "Delete User".tr,
      message: "Are you sure delete user?".tr,
      titleBtnOne: "Delete".tr,
      backgroundButtonOne: Colors.red,
      actionBtnOne: () {
        FirestoreUser.shared.deleteUser(uid: uid);
        users.removeAt(users.indexWhere((user) => user.uid == uid));
        update();
      },
      actionBtnTwo: () {},
    );
  }
}
