import 'package:get/get.dart';
import 'package:together_we_rise/utils/enum/sub_sections.dart';

class SubSectionsViewModel extends GetxController {
  final List<SubSections> _allItems = [
    SubSections.book,
    SubSections.electronic,
    SubSections.clothes,
    SubSections.tools,
    SubSections.other,
  ];

  List<SubSections> items = [
    SubSections.book,
    SubSections.electronic,
    SubSections.clothes,
    SubSections.tools,
    SubSections.other,
  ];

  void onChangeSearchText({required String keyword}) {
    items.clear();

    for (var item in _allItems) {
      if (item.title.toLowerCase().contains(keyword.toLowerCase())) {
        items.add(item);
      }
    }

    update();
  }
}
