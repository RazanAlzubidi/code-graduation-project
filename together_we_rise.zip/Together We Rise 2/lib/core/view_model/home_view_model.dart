import 'package:get/get.dart';
import 'package:together_we_rise/utils/enum/sections.dart';

class HomeViewModel extends GetxController {
  final List<Sections> _allItems = [
    Sections.mathematics,
    Sections.computerScience,
    Sections.english,
    Sections.chemistry,
    Sections.islamicCulture,
    Sections.interiorDesign,
  ];

  List<Sections> items = [
    Sections.mathematics,
    Sections.computerScience,
    Sections.english,
    Sections.chemistry,
    Sections.islamicCulture,
    Sections.interiorDesign,
  ];

  void onChangeSearchText({required String keyword}) {
    items.clear();

    for (var item in _allItems) {
      if (item.title.toLowerCase().contains(keyword.toLowerCase())) {
        items.add(item);
      }
    }

    update();
  }
}
