import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firestore_problem.dart';
import 'package:together_we_rise/model/problem_model.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/widgets/custom_alert_dialog.dart';

class ProblemViewModel extends GetxController {
  String? title, details;

  List<ProblemModel> problems = [];

  bool _validation() {
    return !((title == null || title?.trim() == "") ||
        (details == null || details?.trim() == ""));
  }

  void getProblems() async {
    problems = await FirestoreProblem.shared.getAllProblems();

    problems.sort((a, b) {
      return DateTime.parse(b.dateCreated ?? "")
          .compareTo(DateTime.parse(a.dateCreated ?? ""));
    });

    update();
  }

  Future<void> addProblem() async {
    if (!_validation()) {
      Get.customSnackbar(
          title: "Error".tr,
          message: "Please enter all fields".tr,
          isError: true);
      return;
    }

    Get.customLoader();
    ProblemModel object = ProblemModel(
      title: title,
      details: details,
      dateCreated: DateTime.now().toString(),
      createdBy: UserProfile.shared.currentUser?.uid,
      uid: "",
    );
    try {
      await FirestoreProblem.shared.addProblem(problem: object);
      Future.delayed(const Duration(), () {
        Get.back();
        Get.customSnackbar(
          title: "Done Successfully".tr,
          message: "added successfully".tr,
        );
      });
    } catch (e) {
      Get.customSnackbar(
        title: "Error".tr,
        message: e.toString(),
        isError: true,
      );
    } finally {
      Get.customLoader(isShowLoader: false);
    }
  }

  void deleteProblem({required String uid}) {
    customAlertDialog(
      title: "Delete Problem".tr,
      message: "Are you sure delete problem?".tr,
      titleBtnOne: "Delete".tr,
      backgroundButtonOne: Colors.red,
      actionBtnOne: () {
        FirestoreProblem.shared.deleteProblem(uid: uid);
        problems.removeAt(problems.indexWhere((user) => user.uid == uid));
        update();
      },
      actionBtnTwo: () {},
    );
  }
}
