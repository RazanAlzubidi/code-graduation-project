import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firestore_user.dart';
import 'package:together_we_rise/model/user_model.dart';
import 'package:together_we_rise/utils/enum/user_type.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/admin_pages/dashboard.dart';
import 'package:together_we_rise/view/auth/sign_in_view.dart';
import 'package:together_we_rise/view/tabbar/main_tab_bar.dart';

class AuthViewModel extends GetxController {
  String? name, email, password, repeatPassword;

  bool agreePolicy = false;

  void changeAgreePolicy() {
    agreePolicy = !agreePolicy;
    update();
  }

  bool _validationSignUp() {
    return !((name == null || name == "") ||
        (email == null || email == "") ||
        (password == null || password == "") ||
        (repeatPassword == null || repeatPassword == ""));
  }

  bool _signInValidation() {
    return !((email == null || email?.trim() == "") ||
        (password == null || password == ""));
  }

  bool _forgotPasswordValidation() {
    return !(email == null || email?.trim() == "");
  }

  Future<String?> _createAccountInFirebase() async {
    try {
      UserCredential userCredential =
          await FirestoreUser.shared.auth.createUserWithEmailAndPassword(
        email: email ?? "",
        password: password ?? "",
      );
      return userCredential.user?.uid;
    } on FirebaseAuthException catch (e) {
      String? message;

      if (e.code == "email-already-in-use") {
        message = "email already in use".tr;
      } else {
        message = "Something went wrong! Please try again later".tr;
      }

      Get.customSnackbar(
        title: "Error".tr,
        message: message,
        isError: true,
      );

      throw message;
    } catch (e) {
      Get.customSnackbar(
        title: "Error",
        message: "Something went wrong! Please try again later".tr,
        isError: true,
      );

      throw e.toString();
    }
  }

  void signUp() async {
    if (!_validationSignUp()) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Please enter all fields".tr,
        isError: true,
      );
      return;
    }

    if (!(email ?? "").isEmail) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Please enter a valid email".tr,
        isError: true,
      );
      return;
    }

    if ((password?.length ?? 0) < 8) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Password must be at least 8 characters long".tr,
        isError: true,
      );
      return;
    }

    if ((password?.length ?? 0) > 15) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Password must be at most 15 characters long".tr,
        isError: true,
      );
      return;
    }

    if (password != repeatPassword) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Passwords do not match".tr,
        isError: true,
      );
      return;
    }

    if (!agreePolicy) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Please agree to the terms and conditions".tr,
        isError: true,
      );
      return;
    }

    Get.customLoader();
    String? userId;

    try {
      userId = await _createAccountInFirebase();
    } catch (_) {
      Get.customLoader(isShowLoader: false);
      return;
    }

    if (userId != null) {
      try {
        UserModel user = UserModel(
          uid: userId,
          email: email,
          name: name,
          userType: UserType.user,
        );

        await FirestoreUser.shared.addUser(
          user: user,
        );
        Get.offAll(SignInView());
      } catch (e) {
        Get.customSnackbar(
          title: "Error".tr,
          message: e.toString(),
          isError: true,
        );
      } finally {
        Get.customLoader(isShowLoader: false);
      }
    }
  }

  void signInWithEmailAndPassword() async {
    if (!_signInValidation()) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Please enter all fields".tr,
        isError: true,
      );
      return;
    }

    if (!(email ?? "").isEmail) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Please enter a valid email".tr,
        isError: true,
      );
      return;
    }

    if ((password?.length ?? 0) < 6) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Password must be at least 6 characters long".tr,
        isError: true,
      );
      return;
    }

    if ((password?.length ?? 0) > 15) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Password must be at most 15 characters long".tr,
        isError: true,
      );
      return;
    }

    Get.customLoader();
    try {
      await FirestoreUser.shared.auth.signInWithEmailAndPassword(
        email: email ?? "",
        password: password ?? "",
      );

      UserModel? user = await FirestoreUser.shared
          .getUserByUid(uid: FirestoreUser.shared.auth.currentUser?.uid ?? "");

      if (user?.uid == null) {
        Get.customSnackbar(
          title: "Error".tr,
          message: "Can't login to this account".tr,
          isError: true,
        );
        return;
      }

      UserProfile.shared.setUser(user: user);

      UserProfile.shared.currentUser = user;

      if (user?.userType == UserType.admin) {
        Get.offAll(() => const DashboardView());
      } else {
        Get.offAll(() => const UserTabBar());
      }
    } on FirebaseAuthException catch (e) {
      String? message;
      if (e.code == 'user-not-found') {
        message = "User not found".tr;
      } else if (e.code == 'wrong-password') {
        message = "wrong password".tr;
      } else if (e.code == 'too-many-requests') {
        message = "The account has been temporarily locked".tr;
      } else {
        message = "Something went wrong! Please try again later".tr;
      }

      Get.customSnackbar(
        title: "Error".tr,
        message: message,
        isError: true,
      );
    } finally {
      Get.customLoader(isShowLoader: false);
    }
  }

  // Future<bool> forgotPassword({ @required GlobalKey<ScaffoldState> scaffoldKey, @required String email }) async {
  //
  //   showLoaderDialog(scaffoldKey.currentContext);
  //   try {
  //     await FirebaseAuth.instance.sendPasswordResetEmail(
  //       email: email,
  //     );
  //     showLoaderDialog(scaffoldKey.currentContext, isShowLoader: false);
  //     return true;
  //   } on FirebaseAuthException catch (e) {
  //     showLoaderDialog(scaffoldKey.currentContext, isShowLoader: false);
  //     if (e.code == 'user-not-found') {
  //       scaffoldKey.showTosta(message: "الإيميل غير موجود", isError: true);
  //       return false;
  //     }
  //   }
  //
  // }

  void signOut() async {
    Get.customLoader();
    try {
      await FirebaseAuth.instance.signOut();
      UserProfile.shared.setUser(user: null);
      Get.offAll(() => SignInView());
    } catch (_) {
      Get.customSnackbar(
        title: "Error".tr,
        message: "Something went wrong! Please try again later".tr,
      );
    } finally {
      Get.customLoader(isShowLoader: false);
    }
  }
}
