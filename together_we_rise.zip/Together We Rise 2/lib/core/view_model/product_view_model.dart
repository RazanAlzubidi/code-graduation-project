import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firebase_storage.dart';
import 'package:together_we_rise/core/service/firestore_product.dart';
import 'package:together_we_rise/model/product_model.dart';
import 'package:together_we_rise/utils/enum/file_type.dart';
import 'package:together_we_rise/utils/enum/sub_sections.dart';
import 'package:together_we_rise/utils/enum/type_of_sale.dart';
import 'package:together_we_rise/utils/enum/use_status.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/image_picker_helper.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/widgets/custom_alert_dialog.dart';
import 'package:together_we_rise/view/widgets/custom_alert_sheet.dart';

import '../../utils/enum/sections.dart';

class ProductViewModel extends GetxController {
  String? name, price, details, contactInfo, image;
  TypeOfSale? typeOfSale;
  Sections? section;
  SubSections? subSection;
  UseStatus? useStatus;

  void selectTypeOfSale() {
    List<TypeOfSale> items = [
      TypeOfSale.sale,
      TypeOfSale.buying,
    ];

    customAlertSheet(
      title: "Select Type Of Sale".tr,
      items: items.map((e) => e.title).toList(),
      onTap: (index, _) {
        typeOfSale = items[index];
        update();
      },
    );
  }

  void selectSection() {
    List<Sections> items = [
      Sections.mathematics,
      Sections.computerScience,
      Sections.english,
      Sections.chemistry,
      Sections.islamicCulture,
      Sections.interiorDesign,
    ];

    customAlertSheet(
      title: "Select Specialty".tr,
      items: items.map((e) => e.title).toList(),
      onTap: (index, _) {
        section = items[index];
        update();
      },
    );
  }

  void selectSubSections() {
    List<SubSections> items = [
      SubSections.book,
      SubSections.electronic,
      SubSections.clothes,
      SubSections.tools,
      SubSections.other,
    ];

    customAlertSheet(
      title: "Select Section".tr,
      items: items.map((e) => e.title).toList(),
      onTap: (index, _) {
        subSection = items[index];
        update();
      },
    );
  }

  void selectUseStatus() {
    List<UseStatus> items = [
      UseStatus.newStatus,
      UseStatus.usedInExcellentCondition,
      UseStatus.usedInVeryGoodCondition,
      UseStatus.usedInGoodCondition,
    ];

    customAlertSheet(
      title: "Select Use Status".tr,
      items: items.map((e) => e.title).toList(),
      onTap: (index, _) {
        useStatus = items[index];
        update();
      },
    );
  }

  void selectImage() {
    ImagePickerHelper.shared.getImage(callback: (image) {
      this.image = image;
      update();
    });
  }

  void emptyData() {
    name = null;
    price = null;
    details = null;
    contactInfo = null;
    image = null;
    typeOfSale = null;
    section = null;
    subSection = null;
    useStatus = null;
    update();
  }

  final List<ProductModel> _allProducts = [];

  List<ProductModel> products = [];

  bool _validation() {
    return !((name == null || name == "") ||
        // (specialty == null || specialty == "") ||
        (price == null || price == "") ||
        (details == null || details == "") ||
        (contactInfo == null || contactInfo == "") ||
        image == null ||
        typeOfSale == null ||
        section == null ||
        subSection == null ||
        useStatus == null);
  }

  void getProductsBySection(
      {required Sections section, required SubSections subSection}) async {
    products.clear();
    _allProducts.clear();

    var data = await FirestoreProduct.shared
        .getProductsBySection(section: section, subSection: subSection);

    _allProducts.sort((a, b) {
      return DateTime.parse(b.createdDate ?? "")
          .compareTo(DateTime.parse(a.createdDate ?? ""));
    });

    for (var product in data) {
      products.add(product);
      _allProducts.add(product);
    }

    update();
  }

  void getProductsByUserId({required String uidUser}) async {
    products.clear();
    _allProducts.clear();

    var data =
        await FirestoreProduct.shared.getProductsByUserId(uidUser: uidUser);

    _allProducts.sort((a, b) {
      return DateTime.parse(b.createdDate ?? "")
          .compareTo(DateTime.parse(a.createdDate ?? ""));
    });

    for (var product in data) {
      products.add(product);
      _allProducts.add(product);
    }

    update();
  }

  Future<void> addProduct() async {
    if (!_validation()) {
      Get.customSnackbar(
          title: "Error".tr,
          message: "Please enter all fields".tr,
          isError: true);
      return;
    }

    Get.customLoader();

    String imageURL = "";

    try {
      imageURL = await FirebaseStorageService.shared.uploadFile(
        folderName: "product",
        fileType: FileTypeEnum.image,
        path: image ?? "",
      );
    } catch (_) {
      Get.customLoader(isShowLoader: false);
      Get.customSnackbar(
        title: "Error".tr,
        message: "Something went wrong! Please try again later".tr,
        isError: true,
      );
      return;
    }

    ProductModel object = ProductModel(
      uid: "",
      name: name,
      typeOfSale: typeOfSale,
      specialty: null,
      price: price,
      section: section,
      subSection: subSection,
      useStatus: useStatus,
      details: details,
      contactInfo: contactInfo,
      image: imageURL,
      createdBy: UserProfile.shared.currentUser?.uid,
      createdDate: DateTime.now().toString(),
    );

    try {
      await FirestoreProduct.shared.addProduct(product: object);
      Future.delayed(const Duration(), () {
        emptyData();
        Get.customSnackbar(
          title: "Done Successfully".tr,
          message: "added successfully".tr,
        );
        getProductsByUserId(uidUser: UserProfile.shared.currentUser?.uid ?? "");
      });
    } catch (e) {
      Get.customSnackbar(
        title: "Error".tr,
        message: e.toString(),
        isError: true,
      );
    } finally {
      Get.customLoader(isShowLoader: false);
    }
  }

  Future<void> editProduct({required String uidProduct}) async {
    if (!_validation()) {
      Get.customSnackbar(
          title: "Error".tr,
          message: "Please enter all fields".tr,
          isError: true);
      return;
    }

    Get.customLoader();

    String imageURL = "";

    if (GetUtils.isURL(image ?? "")) {
      imageURL = image ?? "";
    } else {
      try {
        imageURL = await FirebaseStorageService.shared.uploadFile(
          folderName: "product",
          fileType: FileTypeEnum.image,
          path: image ?? "",
        );
      } catch (_) {
        Get.customLoader(isShowLoader: false);
        Get.customSnackbar(
          title: "Error".tr,
          message: "Something went wrong! Please try again later".tr,
          isError: true,
        );
        return;
      }
    }

    ProductModel object = ProductModel(
      uid: uidProduct,
      name: name,
      typeOfSale: typeOfSale,
      specialty: null,
      price: price,
      section: section,
      subSection: subSection,
      useStatus: useStatus,
      details: details,
      contactInfo: contactInfo,
      image: imageURL,
      createdBy: UserProfile.shared.currentUser?.uid,
      createdDate: DateTime.now().toString(),
    );

    try {
      await FirestoreProduct.shared.editProduct(product: object);
      Future.delayed(const Duration(milliseconds: 300), () {
        emptyData();

        Get.back();
        Get.back();

        getProductsByUserId(uidUser: UserProfile.shared.currentUser?.uid ?? "");

        Get.customSnackbar(
          title: "Done Successfully".tr,
          message: "edited successfully".tr,
        );
      });
    } catch (e) {
      Get.customSnackbar(
        title: "Error".tr,
        message: e.toString(),
        isError: true,
      );
    } finally {
      Get.customLoader(isShowLoader: false);
    }
  }

  void deleteProduct({required String uid}) {
    customAlertDialog(
      title: "Delete Product".tr,
      message: "Are you sure delete Product?".tr,
      titleBtnOne: "Delete".tr,
      backgroundButtonOne: Colors.red,
      actionBtnOne: () {
        FirestoreProduct.shared.deleteProduct(uid: uid);
        products.removeAt(products.indexWhere((user) => user.uid == uid));
        update();
        Get.back();
      },
      actionBtnTwo: () {},
    );
  }

  void searchProduct({required String keyword}) {
    products.clear();

    for (var product in _allProducts) {
      if (product.name?.toLowerCase().contains(keyword.toLowerCase()) ??
          false) {
        products.add(product);
      }
    }

    update();
  }
}
