import 'package:get/get.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:together_we_rise/core/service/firestore_order.dart';
import 'package:together_we_rise/model/order_model.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/tabbar/main_tab_bar.dart';
import 'package:together_we_rise/view/widgets/custom_alert_dialog.dart';

class OrderViewModel extends GetxController {
  List<OrderModel> orders = [];

  void getMyPurchases() async {
    orders = await FirestoreOrder.shared.getMyPurchases();

    orders.sort((a, b) {
      return DateTime.parse(b.createdDate ?? "")
          .compareTo(DateTime.parse(a.createdDate ?? ""));
    });

    update();
  }

  Future<bool> checkProductIsOrder({required String uidProduct}) async {
    List<OrderModel> orders = await FirestoreOrder.shared.getMyPurchases();

    if (orders.where((e) => e.uidProduct == uidProduct).isNotEmpty) {
      return true;
    }

    return false;
  }

  void getMySales() async {
    orders = await FirestoreOrder.shared.getMySales();

    orders.sort((a, b) {
      return DateTime.parse(b.createdDate ?? "")
          .compareTo(DateTime.parse(a.createdDate ?? ""));
    });

    update();
  }

  Future<void> addOrder() async {
    Get.customLoader();

    try {
      await FirestoreOrder.shared.addOrder();
      Future.delayed(const Duration(), () async {
        Get.offAll(() => const UserTabBar());
        await customAlertDialog(
          title: "request was successfully".tr,
          message:
              "${"order number:".tr} ${UserProfile.shared.tempOrder?.uid?.getId()}",
          alertType: AlertType.success,
          titleBtnOne: "Done".tr,
          backgroundButtonOne: "#C6BDB0".toHexaColor(),
          showBtnTwo: false,
          actionBtnOne: () {},
          actionBtnTwo: () {},
        );

        UserProfile.shared.tempOrder = null;
      });
    } catch (e) {
      Get.customSnackbar(
        title: "Error".tr,
        message: e.toString(),
        isError: true,
      );
    } finally {
      Get.customLoader(isShowLoader: false);
    }
  }

  Future<void> deleteOrder({required String uidProduct}) async {
    List<OrderModel> orders = await FirestoreOrder.shared.getMyPurchases();

    if (orders.isNotEmpty) {
      FirestoreOrder.shared.deleteOrder(uid: orders.first.uid ?? "");
      Future.delayed(const Duration(milliseconds: 300), () {
        getMyPurchases();
      });
    }
  }
}
