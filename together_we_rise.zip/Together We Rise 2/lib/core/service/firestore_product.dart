import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/model/product_model.dart';
import 'package:together_we_rise/utils/enum/sections.dart';
import 'package:together_we_rise/utils/enum/sub_sections.dart';

class FirestoreProduct {
  static final FirestoreProduct shared = FirestoreProduct();

  final productRef = FirebaseFirestore.instance.collection('Product');

  Future<ProductModel?> getProductByUid({required String uid}) async {
    ProductModel userTemp;
    var user = await productRef.doc(uid).snapshots().first;
    userTemp = ProductModel.fromJson(user.data() ?? {});
    return userTemp;
  }

  Future<List<ProductModel>> getProductsBySection({
    required Sections section,
    required SubSections subSection,
  }) async {
    return productRef
        .where("section", isEqualTo: section.index)
        .where("sub-section", isEqualTo: subSection.index)
        .snapshots()
        .map((QuerySnapshot snapshot) {
      return snapshot.docs.map((doc) {
        return ProductModel.fromJson(doc.data() as Map<String, dynamic>);
      }).toList();
    }).first;
  }

  Future<List<ProductModel>> getProductsByUserId(
      {required String uidUser}) async {
    return productRef
        .where("created-by", isEqualTo: uidUser)
        .snapshots()
        .map((QuerySnapshot snapshot) {
      return snapshot.docs.map((doc) {
        return ProductModel.fromJson(doc.data() as Map<String, dynamic>);
      }).toList();
    }).first;
  }

  Future<void> addProduct({
    required ProductModel product,
  }) async {
    product.uid = productRef.doc().id;

    await productRef.doc(product.uid).set(product.toJson()).catchError((e) {
      throw "Something went wrong! Please try again later".tr;
    });
  }

  Future<void> editProduct({
    required ProductModel product,
  }) async {
    await productRef.doc(product.uid).update(product.toJson()).catchError((e) {
      throw "Something went wrong! Please try again later".tr;
    });
  }

  void deleteProduct({required String uid}) async {
    await productRef.doc(uid).delete();
  }
}
