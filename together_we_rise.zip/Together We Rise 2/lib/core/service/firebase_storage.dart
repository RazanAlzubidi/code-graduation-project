import 'dart:developer';
import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:together_we_rise/utils/enum/file_type.dart';
import 'package:uuid/uuid.dart';

class FirebaseStorageService {
  static final FirebaseStorageService shared = FirebaseStorageService();

  final storageRef = FirebaseStorage.instance.ref();

  Future<String> uploadFile({
    required String folderName,
    required FileTypeEnum fileType,
    required String path,
  }) async {
    try {
      UploadTask uploadTask = storageRef
          .child('$folderName/${const Uuid().v4()}')
          .putFile(
              File(path), SettableMetadata(contentType: fileType.contentType));

      String url = await (await uploadTask).ref.getDownloadURL();

      if (kDebugMode) {
        uploadTask.snapshotEvents.listen((event) {
          var progress =
              event.bytesTransferred.toDouble() / event.totalBytes.toDouble();
          log(progress.toString());
        });
      }

      return url;
    } catch (e) {
      throw e.toString();
    }
  }
}
