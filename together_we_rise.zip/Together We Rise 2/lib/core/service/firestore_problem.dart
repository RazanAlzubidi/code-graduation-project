import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/model/problem_model.dart';

class FirestoreProblem {
  static final FirestoreProblem shared = FirestoreProblem();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final problemRef = FirebaseFirestore.instance.collection('Problem');

  Future<List<ProblemModel>> getAllProblems() async {
    return problemRef.snapshots().map((QuerySnapshot snapshot) {
      return snapshot.docs.map((doc) {
        return ProblemModel.fromJson(doc.data() as Map<String, dynamic>);
      }).toList();
    }).first;
  }

  Future<void> addProblem({
    required ProblemModel problem,
  }) async {
    problem.uid = problemRef.doc().id;

    await problemRef.doc(problem.uid).set(problem.toJson()).catchError((e) {
      throw "Something went wrong! Please try again later".tr;
    });
  }

  void deleteProblem({required String uid}) async {
    await problemRef.doc(uid).delete();
  }
}
