import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:together_we_rise/model/chat_model.dart';

class FirestoreChat {
  static final FirestoreChat shared = FirestoreChat();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final chatRef = FirebaseFirestore.instance.collection('Chat');

  addMessage({
    String? uidReceiver,
    String? message,
  }) async {
    String uid = chatRef.doc().id;

    await chatRef
        .doc(uid)
        .set({
          "uid-sender": auth.currentUser?.uid,
          "uid-receiver": uidReceiver,
          "message": message,
          "date": DateTime.now().toString(),
          "uid": uid,
        })
        .then((value) {})
        .catchError((err) {});
  }

  Stream<List<ChatModel>> getAllMessages() {
    return chatRef.snapshots().map((QuerySnapshot snapshot) {
      return snapshot.docs.map((doc) {
        return ChatModel.fromJson(doc.data() as Map<String, dynamic>);
      }).toList();
    });
  }
}
