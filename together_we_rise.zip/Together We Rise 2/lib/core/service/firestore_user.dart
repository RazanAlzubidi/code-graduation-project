import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/model/user_model.dart';

class FirestoreUser {
  static final FirestoreUser shared = FirestoreUser();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final userRef = FirebaseFirestore.instance.collection('User');

  Future<UserModel?> getUserByUid({required String uid}) async {
    UserModel userTemp;
    var user = await userRef.doc(uid).snapshots().first;
    userTemp = UserModel.fromJson(user.data() ?? {});
    return userTemp;
  }

  Future<List<UserModel>> getAllUsers() async {
    return userRef.snapshots().map((QuerySnapshot snapshot) {
      return snapshot.docs.map((doc) {
        return UserModel.fromJson(doc.data() as Map<String, dynamic>);
      }).toList();
    }).first;
  }

  Future<void> addUser({
    required UserModel user,
  }) async {
    await userRef.doc(user.uid).set(user.toJson()).catchError((e) {
      throw "Something went wrong! Please try again later".tr;
    });
  }

  void deleteUser({required String uid}) async {
    await userRef.doc(uid).delete();
  }
}
