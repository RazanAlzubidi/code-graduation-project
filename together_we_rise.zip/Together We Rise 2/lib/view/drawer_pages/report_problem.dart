import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/problem_view_model.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ReportProblemView extends StatelessWidget {
  ReportProblemView({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProblemViewModel>(
      init: ProblemViewModel(),
      builder: (controller) {
        return Scaffold(
          appBar: const CustomAppBar(),
          body: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(20.r),
              child: Column(
                children: [
                  Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(5.r),
                        decoration: BoxDecoration(
                          color: "#E2D1B9".toHexaColor().withOpacity(0.68),
                          borderRadius: BorderRadius.circular(15.r),
                        ),
                        child: CustomText(
                          text: "Report a problem".tr,
                          fontSize: 20,
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Container(
                        padding: EdgeInsets.all(10.r),

                        child: CustomText(
                          text: "Your on feedback helps us improve".tr,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        Column(
                          children: [
                            CustomText(
                              text: "Title".tr,
                              alignment: Alignment.centerLeft,
                              fontSize: 14,
                            ),
                            SizedBox(
                              height: 20.h,
                            ),
                            Container(
                              padding: EdgeInsets.all(5.r),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                              ),
                              child: TextFormField(
                                onSaved: (value) =>
                                    controller.title = value?.trim(),
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.next,
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 50.h,
                        ),
                        Column(
                          children: [
                            CustomText(
                              text: "Description of problem".tr,
                              alignment: Alignment.centerLeft,
                              fontSize: 14,
                            ),
                            SizedBox(
                              height: 20.h,
                            ),
                            Container(
                              padding: EdgeInsets.all(5.r),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                              ),
                              child: TextFormField(
                                onSaved: (value) =>
                                    controller.details = value?.trim(),
                                textInputAction: TextInputAction.newline,
                                maxLines: null,
                                minLines: 10,
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 50.h,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: Container(
            padding: EdgeInsets.symmetric(
              vertical: 25.r,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  width: 150.w,
                  height: 40.h,
                  child: CustomMainButton(
                    title: "Send".tr,
                    onTap: () {
                      _formKey.currentState?.save();
                      controller.addProblem();
                    },
                  ),
                ),
                SizedBox(
                  width: 150.w,
                  height: 40.h,
                  child: CustomMainButton(
                    title: "Cancel".tr,
                    onTap: () => Get.back(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
