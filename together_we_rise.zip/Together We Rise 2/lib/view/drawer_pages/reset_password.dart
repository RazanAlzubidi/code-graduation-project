import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ResetPasswordView extends StatelessWidget {
  const ResetPasswordView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: Column(
            children: [
              SizedBox(
                height: 100.h,
              ),
              CustomText(
                text:
                    "Enter your new password below to reset your password:".tr,
                alignment: Alignment.centerLeft,
                textAlign: TextAlign.left,
              ),
              SizedBox(
                height: 60.h,
              ),
              Form(
                child: Column(
                  children: [
                    Column(
                      children: [
                        CustomText(
                          text: "Password".tr,
                          alignment: Alignment.centerLeft,
                          textAlign: TextAlign.left,
                        ),
                        SizedBox(
                          height: 5.h,
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.r),
                          color: "#E3E2E0".toHexaColor(),
                          child: TextFormField(
                            textInputAction: TextInputAction.next,
                            obscureText: true,
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30.h,
                    ),
                    Column(
                      children: [
                        CustomText(
                          text: "Password confirmation".tr,
                          alignment: Alignment.centerLeft,
                          textAlign: TextAlign.left,
                        ),
                        SizedBox(
                          height: 5.h,
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.r),
                          color: "#E3E2E0".toHexaColor(),
                          child: TextFormField(
                            textInputAction: TextInputAction.next,
                            obscureText: true,
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 40.h,
              ),
              CustomText(
                text:
                    "The password must contain at least 8 characters at least a capital letter, and at least a number"
                        .tr,
                alignment: Alignment.centerLeft,
                textAlign: TextAlign.left,
                fontSize: 12,
              ),
              SizedBox(
                height: 40.h,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: CustomMainButton(
                  title: "Reset".tr,
                  onTap: () {},
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
