import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:together_we_rise/utils/enum/drawer_tabs.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class MainDrawer extends StatelessWidget {
  MainDrawer({Key? key}) : super(key: key);

  final List<DrawerTabs> _items = [
    DrawerTabs.homePage,
    // DrawerTabs.profile,
    DrawerTabs.changeLanguage,
    DrawerTabs.chat,
    // DrawerTabs.resetPassword,
    DrawerTabs.reportProblem,
    DrawerTabs.logOut,
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.5,
      height: double.infinity,
      color: Theme.of(context).scaffoldBackgroundColor,
      child: Column(
        children: [
          SizedBox(
            height: 100.h,
          ),
          Expanded(
            child: ListView.separated(
              padding: EdgeInsets.all(20.r),
              itemCount: _items.length,
              itemBuilder: (context, index) {
                return _ItemCell(
                  index: index,
                  item: _items[index],
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return Container(
                  height: 0.5.h,
                  color: Colors.black,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final int index;

  final DrawerTabs item;

  const _ItemCell({
    Key? key,
    required this.index,
    required this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => item.action(),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 5.r),
        child: Row(
          children: [
            CustomText(
              text: item.title,
              textColor: item == DrawerTabs.logOut ? Colors.red : Colors.black,
            ),
          ],
        ),
      ),
    );
  }
}
