import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/problem_view_model.dart';
import 'package:together_we_rise/model/problem_model.dart';
import 'package:together_we_rise/view/admin_pages/problems/problem_details.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ProblemsView extends StatelessWidget {
  ProblemsView({Key? key}) : super(key: key);

  final ProblemViewModel controller = Get.put(ProblemViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: GetBuilder<ProblemViewModel>(
        init: ProblemViewModel(),
        initState: (state) {
          controller.getProblems();
        },
        builder: (controller) {
          return ListView.builder(
            padding: EdgeInsets.all(20.r),
            itemCount: controller.problems.length,
            itemBuilder: (context, index) {
              return _ItemCell(
                problem: controller.problems[index],
              );
            },
          );
        },
      ),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final ProblemModel problem;

  const _ItemCell({
    Key? key,
    required this.problem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 20.h,
        ),
        InkWell(
          onTap: () => Get.to(
            () => ProblemDetailsView(
              problem: problem,
            ),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: CustomText(
                      text: problem.title ?? "",
                      alignment: Alignment.centerLeft,
                      textAlign: TextAlign.left,
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      Get.find<ProblemViewModel>()
                          .deleteProblem(uid: problem.uid ?? "");
                    },
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ),
              SizedBox(
                height: 10.h,
              ),
              Container(
                height: 0.5.h,
                color: Colors.black,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
