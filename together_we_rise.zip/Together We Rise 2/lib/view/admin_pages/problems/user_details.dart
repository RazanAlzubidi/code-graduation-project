import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/product_view_model.dart';
import 'package:together_we_rise/model/user_model.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/view/widgets/product_cell.dart';

class UserDetailsView extends StatelessWidget {
  final UserModel user;

  UserDetailsView({
    Key? key,
    required this.user,
  }) : super(key: key);

  final ProductViewModel controller = Get.put(ProductViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black),
        title: Column(
          children: [
            Image.asset(Assets.shared.icHeart),
            Text(
              "Together we rise".tr,
              style: TextStyle(
                color: Assets.shared.primaryColor,
                fontSize: 16,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(20.r),
        width: double.infinity,
        child: Column(
          children: [
            SizedBox(
              height: 30.h,
            ),
            SizedBox(
              height: 40.h,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 10.r),
                      color: Colors.white,
                      child: Center(
                        child: TextField(
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                          onChanged: (value) =>
                              controller.searchProduct(keyword: value.trim()),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    color: Colors.black,
                    width: 40.r,
                    child: const Center(
                        child: Icon(
                      Icons.search_rounded,
                      color: Colors.white,
                    )),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 30.h,
            ),
            GetBuilder<ProductViewModel>(
              init: ProductViewModel(),
              initState: (_) {
                controller.getProductsByUserId(uidUser: user.uid ?? "");
              },
              builder: (controller) {
                return Expanded(
                  child: GridView.count(
                    padding: EdgeInsets.all(20.r),
                    crossAxisCount: 2,
                    mainAxisSpacing: 15.r,
                    crossAxisSpacing: 15.r,
                    childAspectRatio: 0.6.h,
                    children: List.generate(
                      controller.products.length,
                      (index) {
                        return ProductCell(
                          product: controller.products[index],
                          isShowBtnDelete: true,
                        );
                      },
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
