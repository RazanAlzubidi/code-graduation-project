import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/model/problem_model.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ProblemDetailsView extends StatelessWidget {
  final ProblemModel problem;

  const ProblemDetailsView({
    Key? key,
    required this.problem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Padding(
        padding: EdgeInsets.all(20.r),
        child: Column(
          children: [
            SizedBox(
              height: 50.h,
            ),
            Form(
              child: Column(
                children: [
                  Column(
                    children: [
                      CustomText(
                        text: "Title".tr,
                        alignment: Alignment.centerLeft,
                        fontSize: 14,
                      ),
                      TextFormField(
                        initialValue: problem.title,
                        textInputAction: TextInputAction.next,
                        readOnly: true,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                  Column(
                    children: [
                      CustomText(
                        text: "Description of problem".tr,
                        alignment: Alignment.centerLeft,
                        fontSize: 14,
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Container(
                        padding: EdgeInsets.all(5.r),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black),
                        ),
                        child: TextFormField(
                          initialValue: problem.details,
                          textInputAction: TextInputAction.newline,
                          readOnly: true,
                          maxLines: null,
                          minLines: 10,
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 50.h,
                      ),
                      SizedBox(
                        width: 150.w,
                        height: 40.h,
                        child: CustomMainButton(
                          title: "Done".tr,
                          onTap: () => Get.back(),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
