import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/user_view_model.dart';
import 'package:together_we_rise/model/user_model.dart';
import 'package:together_we_rise/view/admin_pages/problems/user_details.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class UsersView extends StatelessWidget {
  UsersView({Key? key}) : super(key: key);

  final UserViewModel controller = Get.put(UserViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Padding(
        padding: EdgeInsets.all(20.r),
        child: GetBuilder<UserViewModel>(
          init: UserViewModel(),
          initState: (state) {
            controller.getUsers();
          },
          builder: (controller) {
            return Column(
              children: [
                SizedBox(
                  height: 50.h,
                ),
                SizedBox(
                  height: 40.h,
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.r),
                          color: Colors.white,
                          child: Center(
                            child: TextField(
                              onChanged: (value) {
                                controller.search(keyword: value.trim());
                              },
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        color: Colors.black,
                        width: 40.r,
                        child: const Center(
                            child: Icon(
                          Icons.search_rounded,
                          color: Colors.white,
                        )),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 50.h,
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: controller.users.length,
                    itemBuilder: (context, index) {
                      return _ItemCell(
                        user: controller.users[index],
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final UserModel user;

  const _ItemCell({
    Key? key,
    required this.user,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 20.h,
        ),
        InkWell(
          onTap: () => Get.to(() => UserDetailsView(
                user: user,
              )),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: CustomText(
                      text: user.name ?? "",
                      alignment: Alignment.centerLeft,
                      textAlign: TextAlign.left,
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      Get.find<UserViewModel>().deleteUser(uid: user.uid ?? "");
                    },
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ),
              SizedBox(
                height: 10.h,
              ),
              Container(
                height: 0.5.h,
                color: Colors.black,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
