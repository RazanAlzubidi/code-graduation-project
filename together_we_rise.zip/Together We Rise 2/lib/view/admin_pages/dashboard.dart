import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/auth_view_model.dart';
import 'package:together_we_rise/view/admin_pages/problems/problems_view.dart';
import 'package:together_we_rise/view/admin_pages/users.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Padding(
        padding: EdgeInsets.all(50.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 50.h,
              child: CustomMainButton(
                title: "Solve Problems".tr,
                onTap: () => Get.to(() => ProblemsView()),
              ),
            ),
            SizedBox(
              height: 60.h,
            ),
            SizedBox(
              height: 50.h,
              child: CustomMainButton(
                title: "Delete User & Product".tr,
                onTap: () => Get.to(() => UsersView()),
              ),
            ),
            SizedBox(
              height: 60.h,
            ),
            SizedBox(
              height: 50.h,
              child: CustomMainButton(
                title: "Logout".tr,
                onTap: () {
                  Get.put(AuthViewModel()).signOut();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
