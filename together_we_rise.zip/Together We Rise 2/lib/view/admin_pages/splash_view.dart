import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/utils/enum/user_type.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/admin_pages/dashboard.dart';
import 'package:together_we_rise/view/auth/sign_in_view.dart';
import 'package:together_we_rise/view/tabbar/main_tab_bar.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class SplashView extends StatefulWidget {
  const SplashView({Key? key}) : super(key: key);

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    UserProfile.shared.getUser().then((user) {
      if (user != null) {
        UserProfile.shared.currentUser = user;

        Future.delayed(const Duration(seconds: 2), () {
          if (user.userType == UserType.admin) {
            Get.offAll(() => const DashboardView());
          } else {
            Get.offAll(() => const UserTabBar());
          }
        });
      } else {
        Future.delayed(const Duration(seconds: 2), () {
          Get.offAll(() => SignInView());
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            Assets.shared.icHeart,
            width: 150.r,
            height: 150.r,
            fit: BoxFit.contain,
          ),
          CustomText(
            text: "Together We Rise".tr,
            fontSize: 20,
            textColor: Theme.of(context).primaryColor,
          ),
        ],
      ),
    );
  }
}
