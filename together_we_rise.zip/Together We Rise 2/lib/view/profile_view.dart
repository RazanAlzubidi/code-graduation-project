import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/utils/styles.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: Column(
            children: [
              SizedBox(
                height: 50.h,
              ),
              Form(
                child: Column(
                  children: [
                    TextFormField(
                      initialValue: UserProfile.shared.currentUser?.name ?? "",
                      textInputAction: TextInputAction.next,
                      readOnly: true,
                      decoration: InputDecoration(
                        focusedBorder: authBorder,
                        hintText: "Name".tr,
                      ),
                    ),
                    SizedBox(
                      height: 15.h,
                    ),
                    TextFormField(
                      initialValue: UserProfile.shared.currentUser?.email ?? "",
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      readOnly: true,
                      decoration: InputDecoration(
                        focusedBorder: authBorder,
                        hintText: "University email".tr,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
