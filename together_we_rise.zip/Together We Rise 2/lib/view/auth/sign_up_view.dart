import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/auth_view_model.dart';
import 'package:together_we_rise/utils/styles.dart';
import 'package:together_we_rise/view/auth/sign_in_view.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class SignUpView extends StatelessWidget {
  SignUpView({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: GetBuilder<AuthViewModel>(
              init: AuthViewModel(),
              builder: (controller) {
                return Column(
                  children: [
                    SizedBox(
                      height: 50.h,
                    ),
                    Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          TextFormField(
                            onSaved: (value) => controller.name = value?.trim(),
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              focusedBorder: authBorder,
                              hintText: "Name".tr,
                            ),
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          TextFormField(
                            onSaved: (value) =>
                                controller.email = value?.trim(),
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              focusedBorder: authBorder,
                              hintText: "Email".tr,
                            ),
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          TextFormField(
                            onSaved: (value) => controller.password = value,
                            textInputAction: TextInputAction.next,
                            obscureText: true,
                            decoration: InputDecoration(
                              focusedBorder: authBorder,
                              hintText: "Password".tr,
                            ),
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          TextFormField(
                            onSaved: (value) =>
                                controller.repeatPassword = value,
                            textInputAction: TextInputAction.done,
                            obscureText: true,
                            decoration: InputDecoration(
                              focusedBorder: authBorder,
                              hintText: "Repeat password".tr,
                            ),
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          CustomText(
                            text:
                                "The password must contain at least 8 "
                                    .tr,
                            fontSize: 12,
                            fontWeight: FontWeight.w100,
                            lineHeight: 1,
                            alignment: Alignment.centerLeft,
                            textAlign: TextAlign.start,
                          ),
                          SizedBox(
                            height: 25.h,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 15.r,
                                height: 15.r,
                                child: Checkbox(
                                  value: controller.agreePolicy,
                                  activeColor: Theme.of(context).primaryColor,
                                  onChanged: (value) =>
                                      controller.changeAgreePolicy(),
                                ),
                              ),
                              SizedBox(
                                width: 10.w,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      CustomText(
                                        text:
                                            "I have read and agree to the ".tr,
                                        fontSize: 12,
                                      ),
                                      CustomText(
                                        text: "Terms".tr,
                                        fontSize: 12,
                                        textColor:
                                            Theme.of(context).primaryColor,
                                      ),
                                      CustomText(
                                        text: " of Use and ".tr,
                                        fontSize: 12,
                                      ),
                                    ],
                                  ),
                                  CustomText(
                                    text: "Privacy Policy".tr,
                                    fontSize: 12,
                                    textColor: Theme.of(context).primaryColor,
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 25.h,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.w),
                            child: CustomMainButton(
                              title: "Sign Up".tr,
                              onTap: () {
                                _formKey.currentState?.save();
                                controller.signUp();
                              },
                            ),
                          ),
                          SizedBox(
                            height: 25.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomText(
                                text: "Already have an account?".tr,
                                fontSize: 14,
                              ),
                              TextButton(
                                onPressed: () => Get.off(() => SignInView()),
                                child: CustomText(
                                  text: "Sign In".tr,
                                  textColor: Theme.of(context).primaryColor,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              }),
        ),
      ),
    );
  }
}
