import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ConfirmEmailView extends StatelessWidget {
  const ConfirmEmailView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 50.h,
                ),
                Image.asset(
                  Assets.shared.icEmail,
                  width: 178.w,
                  height: 113.h,
                  fit: BoxFit.fill,
                ),
                SizedBox(
                  height: 80.h,
                ),
                CustomText(
                  text: "A sign up code has been sent to your".tr,
                  fontSize: 14,
                  fontWeight: FontWeight.w300,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      text: "email, please enter code.".tr,
                      fontSize: 14,
                      fontWeight: FontWeight.w300,
                    ),
                    TextButton(
                      onPressed: () {},
                      child: CustomText(
                        text: "Resend".tr,
                        textColor: Theme.of(context).primaryColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 40.r,
                      height: 40.r,
                      color: "#C4C4C4".toHexaColor(),
                      child: TextFormField(
                        maxLength: 1,
                        textAlign: TextAlign.center,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          counterText: "",
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Container(
                      width: 40.r,
                      height: 40.r,
                      color: "#C4C4C4".toHexaColor(),
                      child: TextFormField(
                        maxLength: 1,
                        textAlign: TextAlign.center,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          counterText: "",
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Container(
                      width: 40.r,
                      height: 40.r,
                      color: "#C4C4C4".toHexaColor(),
                      child: TextFormField(
                        maxLength: 1,
                        textAlign: TextAlign.center,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          counterText: "",
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Container(
                      width: 40.r,
                      height: 40.r,
                      color: "#C4C4C4".toHexaColor(),
                      child: TextFormField(
                        maxLength: 1,
                        textAlign: TextAlign.center,
                        textInputAction: TextInputAction.done,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          counterText: "",
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 50.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: CustomMainButton(
                    title: "Enter".tr,
                    onTap: () {},
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
