import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class EmailLinkView extends StatelessWidget {
  const EmailLinkView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 50.h,
                ),
                Image.asset(
                  Assets.shared.icEmail,
                  width: 178.w,
                  height: 113.h,
                  fit: BoxFit.fill,
                ),
                SizedBox(
                  height: 80.h,
                ),
                CustomText(
                  text: "A password reset link has been sent".tr,
                  fontSize: 14,
                  fontWeight: FontWeight.w300,
                  alignment: Alignment.centerLeft,
                ),
                Row(
                  children: [
                    CustomText(
                      text: "to your email?".tr,
                      fontSize: 14,
                      fontWeight: FontWeight.w300,
                      alignment: Alignment.centerLeft,
                    ),
                    TextButton(
                      onPressed: () {},
                      child: CustomText(
                        text: "Resend".tr,
                        textColor: Theme.of(context).primaryColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Container(
                  height: 1,
                  color: Colors.black,
                ),
                SizedBox(
                  height: 50.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: CustomMainButton(
                    title: "Next".tr,
                    onTap: () {},
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
