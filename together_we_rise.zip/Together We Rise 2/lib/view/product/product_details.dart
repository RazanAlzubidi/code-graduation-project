import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firestore_user.dart';
import 'package:together_we_rise/core/view_model/order_view_model.dart';
import 'package:together_we_rise/core/view_model/product_view_model.dart';
import 'package:together_we_rise/model/order_model.dart';
import 'package:together_we_rise/model/product_model.dart';
import 'package:together_we_rise/model/user_model.dart';
import 'package:together_we_rise/utils/enum/type_of_sale.dart';
import 'package:together_we_rise/utils/enum/use_status.dart';
import 'package:together_we_rise/utils/enum/user_type.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/borrowing/determine_the_date_receipt.dart';
import 'package:together_we_rise/view/chat/chat.dart';
import 'package:together_we_rise/view/product/edit_product.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ProductDetails extends StatelessWidget {
  final ProductModel? product;

  const ProductDetails({
    Key? key,
    required this.product,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: SizedBox(
          width: double.infinity,
          child: Column(
            children: [
              Image.network(
                product?.image ?? "",
                fit: BoxFit.cover,
                width: double.infinity,
                height: 238.h,
              ),
              Padding(
                padding: EdgeInsets.all(20.r),
                child: Column(
                  children: [
                    FutureBuilder<UserModel?>(
                        future: FirestoreUser.shared
                            .getUserByUid(uid: product?.createdBy ?? ""),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return Row(
                              children: [
                                // CircleAvatar(
                                //   radius: 20.r,
                                //   foregroundImage: const NetworkImage(
                                //       "https://i.kinja-img.com/gawker-media/image/upload/c_scale,f_auto,fl_progressive,pg_1,q_80,w_800/ijsi5fzb1nbkbhxa2gc1.png"),
                                // ),
                                // SizedBox(
                                //   width: 10.w,
                                // ),
                                CustomText(
                                  text: snapshot.data?.name ?? "",
                                ),
                              ],
                            );
                          } else {
                            return const SizedBox();
                          }
                        }),
                    SizedBox(
                      height: 15.h,
                    ),
                    _ItemCell(title: "Name".tr, value: product?.name ?? ""),
                    _ItemCell(
                        title: "Price".tr, value: "${product?.price ?? ""} SR"),
                    _ItemCell(
                        title: "Use status".tr,
                        value:
                            (product?.useStatus ?? UseStatus.newStatus).title),
                    _ItemCell(
                        title: "Type of sale".tr,
                        value: (product?.typeOfSale ?? TypeOfSale.sale).title),
                    _ItemCell(
                        title: "Describe".tr, value: product?.details ?? ""),
                    _ItemCell(
                        title: "Contact Information".tr,
                        value: product?.contactInfo ?? ""),
                    Visibility(
                      visible: !(UserProfile.shared.currentUser?.uid ==
                              product?.createdBy ||
                          UserProfile.shared.currentUser?.userType ==
                              UserType.admin),
                      child: Column(
                        children: [
                          Container(
                            height: 1,
                            color: Theme.of(context).primaryColor,
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          GetBuilder<OrderViewModel>(
                            init: OrderViewModel(),
                            builder: (controller) {
                              return FutureBuilder<bool>(
                                future: controller.checkProductIsOrder(
                                    uidProduct: product?.uid ?? ""),
                                builder: (context, snapshot) {
                                  if (!snapshot.hasData) {
                                    return const SizedBox();
                                  }

                                  return Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      ElevatedButton(
                                        onPressed: () => Get.to(() => ChatView(
                                              uidUser: product?.createdBy ?? "",
                                            )),
                                        style: ButtonStyle(
                                          shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                            RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(22.r),
                                            ),
                                          ),
                                          backgroundColor:
                                              MaterialStateProperty.all(
                                            "#C6BDB0".toHexaColor(),
                                          ),
                                          padding: MaterialStateProperty.all(
                                            EdgeInsets.symmetric(
                                                horizontal: 5.r,
                                                vertical: 10.r),
                                          ),
                                        ),
                                        child: CustomText(
                                          text: "seller chat".tr,
                                          textColor:
                                              Theme.of(context).primaryColor,
                                        ),
                                      ),
                                      Visibility(
                                        visible: !(snapshot.data ?? false),
                                        child: ElevatedButton(
                                          onPressed: () {
                                            UserProfile.shared.tempOrder =
                                                OrderModel(
                                              uid: "",
                                              uidProduct: product?.uid,
                                              uidSeller: product?.createdBy,
                                              uidCustomer: UserProfile
                                                  .shared.currentUser?.uid,
                                              isBorrowing: true,
                                              dateReceipt: null,
                                              dateReturn: null,
                                              createdDate:
                                                  DateTime.now().toString(),
                                            );
                                            Get.to(() =>
                                                const DetermineTheDateReceipt());
                                          },
                                          style: ButtonStyle(
                                            shape: MaterialStateProperty.all<
                                                RoundedRectangleBorder>(
                                              RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(22.r),
                                              ),
                                            ),
                                            backgroundColor:
                                                MaterialStateProperty.all(
                                              "#C6BDB0".toHexaColor(),
                                            ),
                                            padding: MaterialStateProperty.all(
                                              EdgeInsets.symmetric(
                                                  horizontal: 5.r,
                                                  vertical: 10.r),
                                            ),
                                          ),
                                          child: CustomText(
                                            text: "borrowing".tr,
                                            textColor:
                                                Theme.of(context).primaryColor,
                                          ),
                                        ),
                                      ),
                                      Visibility(
                                        visible: !(snapshot.data ?? false),
                                        child: ElevatedButton(
                                          onPressed: () {
                                            UserProfile.shared.tempOrder =
                                                OrderModel(
                                              uid: "",
                                              uidProduct: product?.uid,
                                              uidSeller: product?.createdBy,
                                              uidCustomer: UserProfile
                                                  .shared.currentUser?.uid,
                                              isBorrowing: false,
                                              dateReceipt: null,
                                              dateReturn: null,
                                              createdDate:
                                                  DateTime.now().toString(),
                                            );
                                            Get.to(() =>
                                                const DetermineTheDateReceipt());
                                          },
                                          style: ButtonStyle(
                                            shape: MaterialStateProperty.all<
                                                RoundedRectangleBorder>(
                                              RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(22.r),
                                              ),
                                            ),
                                            backgroundColor:
                                                MaterialStateProperty.all(
                                              "#C6BDB0".toHexaColor(),
                                            ),
                                            padding: MaterialStateProperty.all(
                                              EdgeInsets.symmetric(
                                                  horizontal: 5.r,
                                                  vertical: 10.r),
                                            ),
                                          ),
                                          child: CustomText(
                                            text: "purchase".tr,
                                            textColor:
                                                Theme.of(context).primaryColor,
                                          ),
                                        ),
                                      ),
                                      Visibility(
                                        visible: snapshot.data ?? false,
                                        child: ElevatedButton(
                                          onPressed: () {
                                            controller.deleteOrder(
                                                uidProduct: product?.uid ?? "");
                                          },
                                          style: ButtonStyle(
                                            shape: MaterialStateProperty.all<
                                                RoundedRectangleBorder>(
                                              RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(22.r),
                                              ),
                                            ),
                                            backgroundColor:
                                                MaterialStateProperty.all(
                                              "#C6BDB0".toHexaColor(),
                                            ),
                                            padding: MaterialStateProperty.all(
                                              EdgeInsets.symmetric(
                                                  horizontal: 5.r,
                                                  vertical: 10.r),
                                            ),
                                          ),
                                          child: CustomText(
                                            text: "cancel order".tr,
                                            textColor:
                                                Theme.of(context).primaryColor,
                                          ),
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    Visibility(
                      visible: UserProfile.shared.currentUser?.uid ==
                          product?.createdBy,
                      child: Column(
                        children: [
                          Container(
                            height: 1,
                            color: Theme.of(context).primaryColor,
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              ElevatedButton(
                                onPressed: () {
                                  Get.put(ProductViewModel())
                                      .deleteProduct(uid: product?.uid ?? "");
                                },
                                style: ButtonStyle(
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(22.r),
                                    ),
                                  ),
                                  backgroundColor: MaterialStateProperty.all(
                                    "#C6BDB0".toHexaColor(),
                                  ),
                                  padding: MaterialStateProperty.all(
                                    EdgeInsets.symmetric(
                                        horizontal: 5.r, vertical: 10.r),
                                  ),
                                ),
                                child: CustomText(
                                  text: "delete".tr,
                                  textColor: Theme.of(context).primaryColor,
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {},
                                style: ButtonStyle(
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(22.r),
                                    ),
                                  ),
                                  backgroundColor: MaterialStateProperty.all(
                                    "#C6BDB0".toHexaColor(),
                                  ),
                                  padding: MaterialStateProperty.all(
                                    EdgeInsets.symmetric(
                                        horizontal: 5.r, vertical: 10.r),
                                  ),
                                ),
                                child: CustomText(
                                  text: "archive".tr,
                                  textColor: Theme.of(context).primaryColor,
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  Get.to(
                                      () => EditProductView(product: product));
                                },
                                style: ButtonStyle(
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(22.r),
                                    ),
                                  ),
                                  backgroundColor: MaterialStateProperty.all(
                                    "#C6BDB0".toHexaColor(),
                                  ),
                                  padding: MaterialStateProperty.all(
                                    EdgeInsets.symmetric(
                                        horizontal: 5.r, vertical: 10.r),
                                  ),
                                ),
                                child: CustomText(
                                  text: "edit".tr,
                                  textColor: Theme.of(context).primaryColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final String title;
  final String value;

  const _ItemCell({
    Key? key,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        LayoutBuilder(builder: (context, constraints) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: constraints.maxWidth * 0.35,
                child: CustomText(
                  text: title,
                  alignment: Alignment.centerLeft,
                  textAlign: TextAlign.left,
                ),
              ),
              Container(
                width: constraints.maxWidth * 0.6,
                padding: EdgeInsets.all(5.r),
                color: Colors.white,
                child: CustomText(
                  text: value,
                  alignment: Alignment.centerLeft,
                  textAlign: TextAlign.left,
                ),
              ),
            ],
          );
        }),
        SizedBox(
          height: 15.h,
        ),
      ],
    );
  }
}
