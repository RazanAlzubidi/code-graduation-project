import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/product_view_model.dart';
import 'package:together_we_rise/model/product_model.dart';
import 'package:together_we_rise/utils/enum/sections.dart';
import 'package:together_we_rise/utils/enum/sub_sections.dart';
import 'package:together_we_rise/utils/enum/type_of_sale.dart';
import 'package:together_we_rise/utils/enum/use_status.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class EditProductView extends StatelessWidget {
  final ProductModel? product;

  EditProductView({
    Key? key,
    required this.product,
  }) : super(key: key);

  final ProductViewModel _controller = Get.put(ProductViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: GetBuilder<ProductViewModel>(
            init: ProductViewModel(),
            initState: (_) {
              _controller.name = product?.name;
              _controller.typeOfSale = product?.typeOfSale;
              _controller.subSection = product?.subSection;
              _controller.price = product?.price;
              _controller.section = product?.section;
              _controller.useStatus = product?.useStatus;
              _controller.details = product?.details;
              _controller.contactInfo = product?.contactInfo;
              _controller.image = product?.image;
            },
            builder: (controller) {
              return Form(
                child: Column(
                  children: [
                    SizedBox(
                      height: 10.h,
                    ),
                    CustomText(
                      text: "Form information Product".tr,
                      fontSize: 20,
                      fontWeight: FontWeight.w100,
                      textColor: "#6A4814".toHexaColor(),
                    ),
                    SizedBox(
                      height: 20.h,
                    ),
                    LayoutBuilder(builder: (context, constraints) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Name product".tr,
                                alignment: Alignment.centerLeft,
                                fontSize: 14,
                              ),
                              SizedBox(
                                height: 5.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 5.r),
                                width: constraints.maxWidth * 0.6,
                                height: 35.h,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                ),
                                child: TextFormField(
                                  controller: TextEditingController(
                                      text: controller.name),
                                  onChanged: (value) =>
                                      controller.name = value.trim(),
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Type of sale".tr,
                                alignment: Alignment.centerLeft,
                                fontSize: 14,
                              ),
                              SizedBox(
                                height: 5.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 5.r),
                                width: constraints.maxWidth * 0.35,
                                height: 35.h,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                ),
                                child: TextFormField(
                                  onTap: controller.selectTypeOfSale,
                                  controller: TextEditingController(
                                      text: controller.typeOfSale == null
                                          ? ""
                                          : (controller.typeOfSale ??
                                                  TypeOfSale.buying)
                                              .title),
                                  readOnly: true,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    suffixIcon: SizedBox(
                                      child: Icon(
                                        Icons.keyboard_arrow_down_outlined,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      );
                    }),
                    SizedBox(
                      height: 10.h,
                    ),
                    LayoutBuilder(builder: (context, constraints) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Specialty".tr,
                                alignment: Alignment.centerLeft,
                                fontSize: 14,
                              ),
                              SizedBox(
                                height: 5.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 5.r),
                                width: constraints.maxWidth * 0.6,
                                height: 35.h,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                ),
                                child: TextFormField(
                                  onTap: controller.selectSection,
                                  controller: TextEditingController(
                                      text: controller.section == null
                                          ? ""
                                          : (controller.section ??
                                                  Sections.english)
                                              .title),
                                  readOnly: true,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    suffixIcon: SizedBox(
                                      child: Icon(
                                        Icons.keyboard_arrow_down_outlined,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Price".tr,
                                alignment: Alignment.centerLeft,
                                fontSize: 14,
                              ),
                              SizedBox(
                                height: 5.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 5.r),
                                width: constraints.maxWidth * 0.35,
                                height: 35.h,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                ),
                                child: TextFormField(
                                  controller: TextEditingController(
                                      text: controller.price),
                                  onChanged: (value) =>
                                      controller.price = value.trim(),
                                  keyboardType: TextInputType.number,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      );
                    }),
                    SizedBox(
                      height: 10.h,
                    ),
                    LayoutBuilder(builder: (context, constraints) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Section".tr,
                                alignment: Alignment.centerLeft,
                                fontSize: 14,
                              ),
                              SizedBox(
                                height: 5.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 5.r),
                                width: constraints.maxWidth * 0.6,
                                height: 35.h,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                ),
                                child: TextFormField(
                                  onTap: controller.selectSubSections,
                                  controller: TextEditingController(
                                      text: controller.subSection == null
                                          ? ""
                                          : (controller.subSection ??
                                                  SubSections.book)
                                              .title),
                                  readOnly: true,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    suffixIcon: SizedBox(
                                      child: Icon(
                                        Icons.keyboard_arrow_down_outlined,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(),
                        ],
                      );
                    }),
                    SizedBox(
                      height: 10.h,
                    ),
                    LayoutBuilder(builder: (context, constraints) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Use status".tr,
                                alignment: Alignment.centerLeft,
                                fontSize: 14,
                              ),
                              SizedBox(
                                height: 5.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 5.r),
                                width: constraints.maxWidth * 0.6,
                                height: 35.h,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                ),
                                child: TextFormField(
                                  onTap: controller.selectUseStatus,
                                  controller: TextEditingController(
                                      text: controller.useStatus == null
                                          ? ""
                                          : (controller.useStatus ??
                                                  UseStatus.newStatus)
                                              .title),
                                  readOnly: true,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    suffixIcon: SizedBox(
                                      child: Icon(
                                        Icons.keyboard_arrow_down_outlined,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(),
                        ],
                      );
                    }),
                    SizedBox(
                      height: 10.h,
                    ),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  text: "Describe".tr,
                                  alignment: Alignment.centerLeft,
                                  fontSize: 14,
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Container(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 5.r),
                                  width: constraints.maxWidth * 0.6,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.black),
                                  ),
                                  child: TextFormField(
                                    controller: TextEditingController(
                                        text: controller.details),
                                    onChanged: (value) =>
                                        controller.details = value.trim(),
                                    textInputAction: TextInputAction.newline,
                                    maxLines: null,
                                    minLines: 3,
                                    decoration: const InputDecoration(
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(),
                          ],
                        );
                      },
                    ),
                    SizedBox(
                      height: 10.h,
                    ),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  text: "Contact Information".tr,
                                  alignment: Alignment.centerLeft,
                                  fontSize: 14,
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Container(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 5.r),
                                  width: constraints.maxWidth * 0.6,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.black),
                                  ),
                                  child: TextFormField(
                                    controller: TextEditingController(
                                        text: controller.contactInfo),
                                    onChanged: (value) =>
                                        controller.contactInfo = value.trim(),
                                    textInputAction: TextInputAction.newline,
                                    maxLines: null,
                                    minLines: 3,
                                    decoration: const InputDecoration(
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(),
                          ],
                        );
                      },
                    ),
                    SizedBox(
                      height: 20.h,
                    ),
                    Row(
                      children: [
                        CustomText(
                          text: "add a picture".tr,
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        IconButton(
                          onPressed: controller.selectImage,
                          icon: Icon(
                            Icons.image_outlined,
                            size: 36.r,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20.h,
                    ),
                    Visibility(
                      visible: controller.image != null,
                      child: Row(
                        children: [
                          SizedBox(
                            width: 120.r,
                            height: 120.r,
                            child: controller.image == null
                                ? const SizedBox()
                                : GetUtils.isURL(controller.image ?? "")
                                    ? Image.network(
                                        controller.image ?? "",
                                        fit: BoxFit.cover,
                                      )
                                    : Image.file(
                                        File(controller.image ?? ""),
                                        fit: BoxFit.cover,
                                      ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 50.h,
                    ),
                    SizedBox(
                      width: 200.w,
                      child: CustomMainButton(
                        title: "edit".tr,
                        onTap: () => controller.editProduct(
                            uidProduct: product?.uid ?? ""),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
