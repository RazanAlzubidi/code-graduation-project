import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/product_view_model.dart';
import 'package:together_we_rise/utils/enum/sections.dart';
import 'package:together_we_rise/utils/enum/sub_sections.dart';
import 'package:together_we_rise/view/drawer_pages/main_drawer.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/product_cell.dart';

class ProductView extends StatelessWidget {
  final SubSections subSection;
  final Sections section;

  ProductView({
    Key? key,
    required this.section,
    required this.subSection,
  }) : super(key: key);

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  final ProductViewModel controller = Get.put(ProductViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: const CustomAppBar(),
      drawer: MainDrawer(),
      body: Padding(
        padding: EdgeInsets.all(20.w),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            children: [
              SizedBox(
                height: 20.h,
              ),
              Row(
                children: [
                  IconButton(
                    onPressed: () => _scaffoldKey.currentState?.openDrawer(),
                    icon: Icon(
                      Icons.format_list_bulleted_sharp,
                      size: 32.r,
                    ),
                  ),
                  SizedBox(
                    width: 10.w,
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.white,
                      child: Row(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10.w),
                              child: TextField(
                                textAlign: TextAlign.center,
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                ),
                                onChanged: (value) {
                                  controller.searchProduct(
                                    keyword: value.trim(),
                                  );
                                },
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.all(5.r),
                            height: 35.h,
                            width: 35.h,
                            color: Colors.black,
                            child: const Icon(
                              Icons.search_rounded,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 30.h,
              ),
              GetBuilder<ProductViewModel>(
                init: ProductViewModel(),
                initState: (state) {
                  controller.getProductsBySection(
                      section: section, subSection: subSection);
                },
                builder: (controller) {
                  return Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 15.r,
                      crossAxisSpacing: 15.r,
                      childAspectRatio: 0.7.h,
                      children: List.generate(
                        controller.products.length,
                        (index) {
                          return ProductCell(
                            product: controller.products[index],
                          );
                        },
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
