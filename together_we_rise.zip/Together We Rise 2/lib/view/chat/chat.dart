import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firestore_chat.dart';
import 'package:together_we_rise/model/chat_model.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/widgets/custom_loader.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ChatView extends StatelessWidget {
  final String uidUser;

  ChatView({
    Key? key,
    required this.uidUser,
  }) : super(key: key);

  final TextEditingController _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: const Icon(
            Icons.close,
            color: Colors.black,
          ),
          tooltip: "back".tr,
        ),
        // actions: [
        //   Padding(
        //     padding: EdgeInsets.only(right: 20.r),
        //     child: const CircleAvatar(
        //       radius: 20,
        //       foregroundImage: NetworkImage(
        //           "https://i.kinja-img.com/gawker-media/image/upload/c_scale,f_auto,fl_progressive,pg_1,q_80,w_800/ijsi5fzb1nbkbhxa2gc1.png"),
        //     ),
        //   ),
        // ],
      ),
      body: StreamBuilder<List<ChatModel>>(
          stream: FirestoreChat.shared.getAllMessages(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              List<ChatModel> messages = [];

              String uidCurrentUser = UserProfile.shared.currentUser?.uid ?? "";

              for (var message in snapshot.data ?? []) {
                if ((message.uidSender == uidCurrentUser ||
                        message.uidReceiver == uidCurrentUser) &&
                    (message.uidReceiver == uidUser ||
                        message.uidSender == uidUser)) {
                  messages.add(message);
                }
              }

              messages.sort((a, b) {
                return DateTime.parse(a.date ?? "")
                    .compareTo(DateTime.parse(b.date ?? ""));
              });

              return ListView.builder(
                padding: EdgeInsets.all(20.r),
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  return _ItemCell(
                    message: messages[index],
                  );
                },
              );
            } else {
              return const Center(
                child: CustomLoader(),
              );
            }
          }),
      bottomNavigationBar: Container(
        height: 68.h,
        color: "#73634C".toHexaColor().withOpacity(0.21),
        child: Column(
          children: [
            Row(
              children: [
                RotationTransition(
                  turns: const AlwaysStoppedAnimation(180 / 360),
                  child: IconButton(
                    onPressed: () {
                      var message = _textController.text.trim();

                      if (message != "") {
                        FirestoreChat.shared
                            .addMessage(uidReceiver: uidUser, message: message);
                        _textController.text = "";
                      }
                    },
                    icon: Icon(
                      Icons.send,
                      size: 28.r,
                    ),
                  ),
                ),
                SizedBox(
                  width: 5.w,
                ),
                Expanded(
                  child: TextField(
                    controller: _textController,
                    decoration: InputDecoration(
                      hintText: "start writing".tr,
                      border: InputBorder.none,
                    ),
                  ),
                ),
                SizedBox(
                  width: 5.w,
                ),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.attach_file,
                    size: 28.r,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 10.h,
            )
          ],
        ),
      ),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final ChatModel message;

  const _ItemCell({Key? key, required this.message}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.r),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Visibility(
            visible: UserProfile.shared.currentUser?.uid == message.uidSender,
            child: const Expanded(child: SizedBox()),
          ),
          // Visibility(
          //   visible: UserProfile.shared.currentUser?.uid != message.uidSender,
          //   child: Row(
          //     children: [
          //       const CircleAvatar(
          //         radius: 20,
          //         foregroundImage: NetworkImage(
          //             "https://i.kinja-img.com/gawker-media/image/upload/c_scale,f_auto,fl_progressive,pg_1,q_80,w_800/ijsi5fzb1nbkbhxa2gc1.png"),
          //       ),
          //       SizedBox(
          //         width: 5.w,
          //       ),
          //     ],
          //   ),
          // ),
          Flexible(
            child: Container(
              padding: EdgeInsets.all(10.r),
              decoration: BoxDecoration(
                color: "#E2D1B9".toHexaColor().withOpacity(0.68),
                borderRadius: BorderRadius.circular(25.r),
              ),
              child: CustomText(
                alignment:
                    (UserProfile.shared.currentUser?.uid == message.uidSender)
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                textAlign: TextAlign.left,
                text: message.message ?? "",
              ),
            ),
          ),
          Visibility(
            visible:
                !(UserProfile.shared.currentUser?.uid == message.uidSender),
            child: const Expanded(child: SizedBox()),
          ),
        ],
      ),
    );
  }
}
