import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/user_view_model.dart';
import 'package:together_we_rise/model/user_model.dart';
import 'package:together_we_rise/view/chat/chat.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ChatUsers extends StatelessWidget {
  ChatUsers({Key? key}) : super(key: key);

  final UserViewModel _controller = Get.put(UserViewModel());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: GetBuilder<UserViewModel>(
          init: UserViewModel(),
          initState: (_) {
            _controller.getUsersChat();
          },
          builder: (controller) {
            return ListView.separated(
              padding: EdgeInsets.all(20.r),
              itemCount: controller.users.length,
              itemBuilder: (context, index) {
                return _ItemCell(
                  user: controller.users[index],
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 10.h),
                  height: 1,
                  color: Theme.of(context).primaryColor,
                );
              },
            );
          }),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final UserModel user;

  const _ItemCell({
    Key? key,
    required this.user,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Get.to(() => ChatView(uidUser: user.uid ?? "")),
      child: Row(
        children: [
          Container(
            width: 70.r,
            height: 70.r,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border:
                  Border.all(color: Theme.of(context).primaryColor, width: 2),
            ),
            child: Icon(
              Icons.person_outline,
              color: Theme.of(context).primaryColor,
              size: 42.r,
            ),
          ),
          SizedBox(
            width: 10.w,
          ),
          CustomText(
            text: user.name ?? "",
            textColor: Theme.of(context).primaryColor,
            fontSize: 18,
          ),
        ],
      ),
    );
  }
}
