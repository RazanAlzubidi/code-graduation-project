import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/payment.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

import 'determine_the_date_return.dart';

class DetermineTheDateReceipt extends StatefulWidget {
  const DetermineTheDateReceipt({Key? key}) : super(key: key);

  @override
  State<DetermineTheDateReceipt> createState() =>
      _DetermineTheDateReceiptState();
}

class _DetermineTheDateReceiptState extends State<DetermineTheDateReceipt> {
  DateTime? _dateSelected;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(20.r),
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                SizedBox(
                  height: 40.h,
                ),
                Container(
                  padding: EdgeInsets.all(15.r),
                  constraints: BoxConstraints(maxWidth: 250.w),
                  decoration: BoxDecoration(
                    color: "#C6BDB0".toHexaColor(),
                    borderRadius: BorderRadius.circular(15.r),
                  ),
                  child: CustomText(
                    text: "Determine The Date receipt".tr,
                  ),
                ),
              ],
            ),
            TableCalendar(
              firstDay: DateTime.now(),
              headerStyle: const HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
              ),
              lastDay: DateTime.now().add(
                const Duration(days: 365),
              ),
              currentDay: _dateSelected,
              focusedDay: DateTime.now(),
              onDaySelected: (selectedDay, focusedDay) {
                _dateSelected = focusedDay;
                setState(() {});
              },
            ),
            Column(
              children: [
                Container(
                  height: 1,
                  color: Theme.of(context).primaryColor,
                ),
                SizedBox(
                  height: 15.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(22.r),
                          ),
                        ),
                        backgroundColor: MaterialStateProperty.all(
                          "#C6BDB0".toHexaColor(),
                        ),
                        padding: MaterialStateProperty.all(
                          EdgeInsets.symmetric(
                              horizontal: 25.r, vertical: 10.r),
                        ),
                      ),
                      child: CustomText(
                        text: "Back".tr,
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        UserProfile.shared.tempOrder?.dateReceipt =
                            (_dateSelected ?? DateTime.now()).toString();

                        if (UserProfile.shared.tempOrder?.isBorrowing ?? true) {
                          Get.to(() => const DetermineTheDateReturn());
                        } else {
                          Get.to(() => const PaymentView());
                        }
                      },
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(22.r),
                          ),
                        ),
                        backgroundColor: MaterialStateProperty.all(
                          "#C6BDB0".toHexaColor(),
                        ),
                        padding: MaterialStateProperty.all(
                          EdgeInsets.symmetric(
                              horizontal: 25.r, vertical: 10.r),
                        ),
                      ),
                      child: CustomText(
                        text: "Next".tr,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15.h,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
