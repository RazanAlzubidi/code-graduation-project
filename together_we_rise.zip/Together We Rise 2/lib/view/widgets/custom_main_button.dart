import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class CustomMainButton extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  const CustomMainButton({
    Key? key,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onTap,
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all("#C6BDB0".toHexaColor()),
        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.r),
          ),
        ),
      ),
      child: CustomText(
        text: title,
      ),
    );
  }
}
