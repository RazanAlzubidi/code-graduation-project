import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class CategoryCell extends StatelessWidget {
  final String? image;
  final String? title;

  const CategoryCell({Key? key, required this.image, required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.black,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              color: Colors.white,
              child: Image.asset(
                image ?? "",
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(
            height: 10.h,
          ),
          CustomText(
            text: title ?? "",
            textColor: Theme.of(context).primaryColor,
          ),
        ],
      ),
    );
  }
}
