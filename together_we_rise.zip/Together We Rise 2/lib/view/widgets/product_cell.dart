import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/product_view_model.dart';
import 'package:together_we_rise/model/product_model.dart';
import 'package:together_we_rise/view/product/product_details.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class ProductCell extends StatelessWidget {
  final ProductModel? product;
  final bool isShowBtnDelete;

  const ProductCell({
    Key? key,
    required this.product,
    this.isShowBtnDelete = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Get.to(
        () => ProductDetails(
          product: product,
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.black,
                ),
              ),
              child: Column(
                children: [
                  Expanded(
                    child: Image.network(
                      product?.image ?? "",
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 10.w,
                      vertical: 5.h,
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            CustomText(
                              text: "Name: ".tr,
                              fontSize: 14,
                            ),
                            CustomText(
                              text: product?.name ?? "",
                              fontSize: 14,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 5.h,
                        ),
                        Row(
                          children: [
                            CustomText(
                              text: "Price: ".tr,
                              fontSize: 14,
                            ),
                            CustomText(
                              text: "${product?.price} ${"SR".tr}",
                              fontSize: 14,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Visibility(
            visible: isShowBtnDelete,
            child: Column(
              children: [
                SizedBox(
                  height: 5.h,
                ),
                SizedBox(
                  height: 30.h,
                  child: ElevatedButton(
                    onPressed: () {
                      Get.put(ProductViewModel())
                          .deleteProduct(uid: product?.uid ?? "");
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.red),
                    ),
                    child: CustomText(
                      text: "Delete".tr,
                      textColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
