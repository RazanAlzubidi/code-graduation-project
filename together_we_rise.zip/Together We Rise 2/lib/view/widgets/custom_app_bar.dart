import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/utils/assets.dart';

class CustomAppBar extends StatelessWidget with PreferredSizeWidget {
  const CustomAppBar({
    Key? key,
  }) : super(key: key);

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      centerTitle: true,
      title: Column(
        children: [
          Image.asset(Assets.shared.icHeart),
          Text(
            "Together We Rise".tr,
            style: TextStyle(
              color: Assets.shared.primaryColor,
              fontSize: 16,
              fontWeight: FontWeight.w200,
            ),
          ),
        ],
      ),
      leading: Navigator.of(context).canPop()
          ? IconButton(
              onPressed: () => Get.back(),
              tooltip: "Back".tr,
              icon: const Icon(Icons.arrow_back_ios),
            )
          : const SizedBox(),
      iconTheme: IconThemeData(
        color: Theme.of(context).primaryColor, //change your color here
      ),
    );
  }
}
