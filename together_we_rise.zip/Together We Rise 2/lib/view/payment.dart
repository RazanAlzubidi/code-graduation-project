import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/order_view_model.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/utils/enum/payment_type.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

class PaymentView extends StatelessWidget {
  const PaymentView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          children: [
            SizedBox(
              height: 20.h,
            ),
            Image.asset(
              Assets.shared.icMoney,
              width: 130.r,
              height: 130.r,
            ),
            SizedBox(
              height: 20.h,
            ),
            CustomText(
              text: "How would you like pay?".tr,
            ),
            SizedBox(
              height: 20.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 60.w),
              child: Container(
                height: 0.5,
                color: Colors.black,
              ),
            ),
            SizedBox(
              height: 50.h,
            ),
            Expanded(
              child: ListView.builder(
                itemCount: PaymentType.values.length,
                itemBuilder: (context, index) {
                  return _ItemCell(
                    index: index,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ItemCell extends StatelessWidget {
  final int index;

  const _ItemCell({
    Key? key,
    required this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: () {
            Get.put(OrderViewModel()).addOrder();
          },
          child: Padding(
            padding: EdgeInsets.all(20.r),
            child: Row(
              children: [
                Image.asset(PaymentType.values[index].icon),
                SizedBox(
                  width: 10.w,
                ),
                CustomText(
                  text: PaymentType.values[index].title,
                ),
              ],
            ),
          ),
        ),
        Container(
          height: 0.5,
          color: Theme.of(context).primaryColor,
        ),
      ],
    );
  }
}
