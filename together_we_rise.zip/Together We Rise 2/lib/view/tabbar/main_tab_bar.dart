import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:together_we_rise/view/tabbar/add_product.dart';
import 'package:together_we_rise/view/tabbar/home_view.dart';
import 'package:together_we_rise/view/tabbar/profile_view.dart';

class UserTabBar extends StatelessWidget {
  const UserTabBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: TabBarView(
          children: [
            HomeView(),
            const AddProductView(),
            ProfileView(),
          ],
        ),
        bottomNavigationBar: SafeArea(
          child: Container(
            padding: EdgeInsets.only(top: 5.r),
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(color: Colors.grey, width: 3),
              ),
            ),
            child: TabBar(
              indicatorColor: Colors.transparent,
              labelColor: Theme.of(context).primaryColor,
              unselectedLabelColor: Colors.black87,
              tabs: [
                Tab(
                  icon: Icon(
                    Icons.home_outlined,
                    size: 42.r,
                  ),
                ),
                Tab(
                  icon: Icon(
                    Icons.add_circle_outline,
                    size: 42.r,
                  ),
                ),
                Tab(
                  icon: Icon(
                    Icons.person_outline,
                    size: 42.r,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
