import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/home_view_model.dart';
import 'package:together_we_rise/utils/enum/sections.dart';
import 'package:together_we_rise/view/drawer_pages/main_drawer.dart';
import 'package:together_we_rise/view/sub_sections_view.dart';
import 'package:together_we_rise/view/widgets/category_cell.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';

class HomeView extends StatelessWidget {
  HomeView({Key? key}) : super(key: key);

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: const CustomAppBar(),
      drawer: MainDrawer(),
      body: Padding(
        padding: EdgeInsets.all(20.w),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            children: [
              SizedBox(
                height: 20.h,
              ),
              Row(
                children: [
                  IconButton(
                    onPressed: () => _scaffoldKey.currentState?.openDrawer(),
                    icon: Icon(
                      Icons.format_list_bulleted_sharp,
                      size: 32.r,
                    ),
                  ),
                  SizedBox(
                    width: 10.w,
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.white,
                      child: Row(
                        children: [
                          GetBuilder<HomeViewModel>(
                              init: HomeViewModel(),
                              builder: (controller) {
                                return Expanded(
                                  child: Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.w),
                                    child: TextField(
                                      textAlign: TextAlign.center,
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                      ),
                                      onChanged: (value) {
                                        controller.onChangeSearchText(
                                          keyword: value.trim(),
                                        );
                                      },
                                    ),
                                  ),
                                );
                              }),
                          Container(
                            padding: EdgeInsets.all(5.r),
                            height: 35.h,
                            width: 35.h,
                            color: Colors.black,
                            child: const Icon(
                              Icons.search_rounded,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 30.h,
              ),
              Expanded(
                child: GetBuilder<HomeViewModel>(
                  init: HomeViewModel(),
                  builder: (controller) {
                    return GridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 15.r,
                      crossAxisSpacing: 15.r,
                      children: List.generate(
                        controller.items.length,
                        (index) {
                          return InkWell(
                            onTap: () => Get.to(
                              () => SubSectionsView(
                                section: controller.items[index],
                              ),
                            ),
                            child: CategoryCell(
                              image: controller.items[index].image,
                              title: controller.items[index].title,
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
