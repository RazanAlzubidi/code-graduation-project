import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/service/firestore_product.dart';
import 'package:together_we_rise/core/view_model/order_view_model.dart';
import 'package:together_we_rise/core/view_model/product_view_model.dart';
import 'package:together_we_rise/core/view_model/profile_view_model.dart';
import 'package:together_we_rise/model/product_model.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/utils/enum/profile_page_type.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/drawer_pages/main_drawer.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';
import 'package:together_we_rise/view/widgets/product_cell.dart';

class ProfileView extends StatelessWidget {
  ProfileView({Key? key}) : super(key: key);

  final OrderViewModel controller = Get.put(OrderViewModel());

  final ProductViewModel productController = Get.put(ProductViewModel());

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
          icon: const Icon(
            Icons.format_list_bulleted_sharp,
            color: Colors.black,
          ),
        ),
        title: Column(
          children: [
            Image.asset(Assets.shared.icHeart),
            Text(
              "Together We Rise".tr,
              style: TextStyle(
                color: Assets.shared.primaryColor,
                fontSize: 16,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
      ),
      drawer: MainDrawer(),
      body: SizedBox(
        width: double.infinity,
        child: GetBuilder<ProfileViewModel>(
          init: ProfileViewModel(),
          initState: (_) {
            controller.getMyPurchases();
            productController.getProductsByUserId(
                uidUser: UserProfile.shared.currentUser?.uid ?? "");
          },
          builder: (profileController) {
            return Column(
              children: [
                SizedBox(
                  height: 30.h,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      child: TextButton(
                        onPressed: () {
                          profileController.profileType =
                              ProfilePageType.mySales;
                          profileController.update();
                        },
                        child: CustomText(
                          text: "my sales".tr,
                          textColor: profileController.profileType ==
                                  ProfilePageType.mySales
                              ? Theme.of(context).primaryColor
                              : Colors.black,
                          fontWeight: profileController.profileType ==
                                  ProfilePageType.mySales
                              ? FontWeight.w500
                              : FontWeight.w100,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      child: TextButton(
                        onPressed: () {
                          profileController.profileType =
                              ProfilePageType.myPurchases;
                          profileController.update();
                        },
                        child: CustomText(
                          text: "my purchases".tr,
                          textColor: profileController.profileType ==
                                  ProfilePageType.myPurchases
                              ? Theme.of(context).primaryColor
                              : Colors.black,
                          fontWeight: profileController.profileType ==
                                  ProfilePageType.myPurchases
                              ? FontWeight.w500
                              : FontWeight.w100,
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  height: 0.5,
                  color: Theme.of(context).primaryColor,
                ),
                GetBuilder<ProductViewModel>(
                    init: ProductViewModel(),
                    builder: (productController) {
                      return GetBuilder<OrderViewModel>(
                        init: OrderViewModel(),
                        builder: (controller) {
                          return Expanded(
                            child: GridView.count(
                              padding: EdgeInsets.all(20.r),
                              crossAxisCount: 2,
                              mainAxisSpacing: 15.r,
                              crossAxisSpacing: 15.r,
                              childAspectRatio: 0.7.h,
                              children: List.generate(
                                profileController.profileType ==
                                        ProfilePageType.mySales
                                    ? productController.products.length
                                    : controller.orders.length,
                                (index) {
                                  if (profileController.profileType ==
                                      ProfilePageType.mySales) {
                                    return ProductCell(
                                      product:
                                          productController.products[index],
                                    );
                                  }

                                  return FutureBuilder<ProductModel?>(
                                    future: FirestoreProduct.shared
                                        .getProductByUid(
                                            uid: controller
                                                    .orders[index].uidProduct ??
                                                ""),
                                    builder: (context, snapshot) {
                                      if (snapshot.hasData) {
                                        return ProductCell(
                                          product: snapshot.data,
                                        );
                                      } else {
                                        return const SizedBox();
                                      }
                                    },
                                  );
                                },
                              ),
                            ),
                          );
                        },
                      );
                    }),
              ],
            );
          },
        ),
      ),
    );
  }
}
