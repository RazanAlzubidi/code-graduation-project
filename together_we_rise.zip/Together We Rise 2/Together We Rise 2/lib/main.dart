import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:together_we_rise/utils/assets.dart';
import 'package:together_we_rise/utils/binding.dart';
import 'package:together_we_rise/utils/enum/language_enum.dart';
import 'package:together_we_rise/utils/extenstion.dart';
import 'package:together_we_rise/utils/localization_service.dart';
import 'package:together_we_rise/utils/user_profile.dart';
import 'package:together_we_rise/view/splash_view.dart';
import 'package:together_we_rise/view/widgets/custom_loader.dart';

import 'core/view_model/loader.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await GetStorage.init();

  await Firebase.initializeApp().then((_) {
    FirebaseFirestore.instance.settings =
        const Settings(persistenceEnabled: false);
  });
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ScreenUtilInit(builder: () {
        return Stack(
          children: [
            GetMaterialApp(
              locale: UserProfile.shared.language?.locale ?? Get.deviceLocale,
              fallbackLocale: Get.deviceLocale,
              debugShowCheckedModeBanner: false,
              translations: LocalizationService(),
              initialBinding: Binding(),
              title: 'Together We Rise'.tr,
              theme: ThemeData(
                primaryColor: Assets.shared.primaryColor,
                scaffoldBackgroundColor: "#f4eee8".toHexaColor(),
                colorScheme: ColorScheme.fromSwatch().copyWith(
                  secondary: Assets.shared.secondaryColor,
                ),
                appBarTheme: AppBarTheme(
                  color: Assets.shared.primaryColor,
                ),
                fontFamily: Assets.shared.primaryFont,
                textSelectionTheme: TextSelectionThemeData(
                    cursorColor: Assets.shared.primaryColor),
              ),
              // initialBinding: Binding(),
              home: const SplashView(),
            ),
            GetBuilder<LoaderViewModel>(
              init: LoaderViewModel(),
              builder: (controller) {
                return Visibility(
                  visible: controller.isActiveLoader,
                  child: const CustomLoader(),
                );
              },
            ),
          ],
        );
      }),
    );
  }
}
