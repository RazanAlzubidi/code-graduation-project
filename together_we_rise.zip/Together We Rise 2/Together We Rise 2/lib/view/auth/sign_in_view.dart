import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:together_we_rise/core/view_model/auth_view_model.dart';
import 'package:together_we_rise/utils/styles.dart';
import 'package:together_we_rise/view/auth/sign_up_view.dart';
import 'package:together_we_rise/view/widgets/custom_app_bar.dart';
import 'package:together_we_rise/view/widgets/custom_main_button.dart';
import 'package:together_we_rise/view/widgets/custom_text.dart';

import 'forgot_password_view.dart';

class SignInView extends StatelessWidget {
  SignInView({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: Column(
            children: [
              SizedBox(
                height: 50.h,
              ),
              GetBuilder<AuthViewModel>(
                init: AuthViewModel(),
                builder: (controller) {
                  return Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          onSaved: (value) => controller.email = value?.trim(),
                          decoration: InputDecoration(
                            focusedBorder: authBorder,
                            hintText: "University email".tr,
                          ),
                        ),
                        SizedBox(
                          height: 30.h,
                        ),
                        TextFormField(
                          onSaved: (value) =>
                              controller.password = value?.trim(),
                          textInputAction: TextInputAction.next,
                          obscureText: true,
                          decoration: InputDecoration(
                            focusedBorder: authBorder,
                            hintText: "Password".tr,
                          ),
                        ),
                        SizedBox(
                          height: 100.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          child: CustomMainButton(
                            title: "Login".tr,
                            onTap: () {
                              _formKey.currentState?.save();
                              controller.signInWithEmailAndPassword();
                            },
                          ),
                        ),
                        SizedBox(
                          height: 25.h,
                        ),
                        TextButton(
                          onPressed: () =>
                              Get.to(() => const ForgotPasswordView()),
                          child: CustomText(
                            text: "Forget password?".tr,
                            textColor: Theme.of(context).primaryColor,
                            fontSize: 16,
                            fontWeight: FontWeight.w200,
                          ),
                        ),
                        SizedBox(
                          height: 15.h,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CustomText(
                              text: "Don't have an account?".tr,
                              fontSize: 14,
                            ),
                            TextButton(
                              onPressed: () => Get.to(() => SignUpView()),
                              child: CustomText(
                                text: "Sign Up".tr,
                                textColor: Theme.of(context).primaryColor,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
